import {geoOrthographic,geoPath,geoGraticule10,geoDistance} from "./vendor/globe-projection.mjs";
let landRequest;
function coastlines() {
  landRequest ??= fetch("/vendor/globe-land.json").then(r => {
    if (!r.ok) throw Error("Map data unavailable");
    return r.json();
  }).catch(error => {landRequest=undefined;throw error;});
  return landRequest;
}
export async function serverGlobe(latitude,longitude,t) {
  const land=await coastlines();
  const container=document.createElement("div");
  container.style.cssText="background:radial-gradient(ellipse at 50% 42%,#123d4d,#091e2b 75%);border-radius:16px;padding:10px;text-align:center;color:#e8f5f4;margin:10px 0";
  const canvas=document.createElement("canvas");
  canvas.tabIndex=0;
  canvas.setAttribute("aria-label",t("كرة أرضية تفاعلية. استخدم الأسهم للتدوير.","Interactive globe. Use the arrow keys to rotate."));
  canvas.style.cssText="width:min(100%,310px);height:auto;display:block;margin:auto;cursor:grab;touch-action:none";
  const size=320, radius=141;
  const density=Math.min(2,window.devicePixelRatio||1);
  canvas.width=canvas.height=size*density;
  const ctx=canvas.getContext("2d");
  if(!ctx) throw Error("Canvas unavailable");
  ctx.scale(density,density);
  const projection=geoOrthographic().translate([160,160]).scale(radius);
  const path=geoPath(projection,ctx), grid=geoGraticule10(), pin=[longitude,latitude];
  let lon=longitude,lat=latitude;
  function draw() {
    projection.rotate([-lon,-lat]);
    ctx.clearRect(0,0,size,size);
    const ocean=ctx.createRadialGradient(114,98,10,160,160,radius);
    ocean.addColorStop(0,"#356a7d");ocean.addColorStop(1,"#143647");
    ctx.beginPath();path({type:"Sphere"});ctx.fillStyle=ocean;ctx.fill();
    ctx.strokeStyle="#79b3b9";ctx.lineWidth=1;ctx.stroke();
    ctx.beginPath();path(land);ctx.fillStyle="#82b6ab";ctx.fill();
    ctx.beginPath();path(grid);ctx.strokeStyle="rgba(205,236,228,.22)";ctx.lineWidth=.55;ctx.stroke();
    if(geoDistance([lon,lat],pin)<Math.PI/2){
      const [x,y]=projection(pin);
      for(const [r,color] of [[11,"rgba(255,193,97,.30)"],[6,"#142b36"],[4,"#ffd277"]]){
        ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();
      }
    }
  }
  function rotate(x,y){lon=(lon+x)%360;lat=Math.max(-90,Math.min(90,lat+y));draw();}
  let drag;
  canvas.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,id:e.pointerId};canvas.setPointerCapture(e.pointerId);canvas.style.cursor="grabbing";};
  canvas.onpointermove=e=>{
    if(drag?.id!==e.pointerId)return;
    const k=130/Math.max(1,canvas.clientWidth);
    rotate((drag.x-e.clientX)*k,(e.clientY-drag.y)*k);drag.x=e.clientX;drag.y=e.clientY;
  };
  canvas.onlostpointercapture=()=>{drag=null;canvas.style.cursor="grab";};
  canvas.onkeydown=e=>{
    const delta={ArrowLeft:[15,0],ArrowRight:[-15,0],ArrowUp:[0,-10],ArrowDown:[0,10]}[e.key];
    if(delta){e.preventDefault();rotate(...delta);}
  };
  const reset=document.createElement("button");
  reset.type="button";reset.textContent=t("توسيط الخادم","Center on server");
  reset.style.cssText="background:#174451;color:#ecf6f2;border:1px solid #557e84;border-radius:18px;padding:7px 14px;cursor:pointer";
  reset.onclick=()=>{lon=longitude;lat=latitude;draw();};
  container.append(canvas,reset);draw();return container;
}
