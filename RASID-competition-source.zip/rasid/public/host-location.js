class HostLocation extends HTMLElement {
  connectedCallback() {
    if (this.firstChild) return;
    const en = this.getAttribute("lang") !== "ar";
    const t = (ar, english) => en ? english : ar;
    const details = document.createElement("details");
    const summary = document.createElement("summary");
    summary.textContent = t("خريطة خادم الموقع", "Website server map");
    summary.style.cssText = "cursor:pointer;font-weight:650;padding:10px 0";
    const panel = document.createElement("div");
    panel.setAttribute("aria-live","polite");
    details.append(summary,panel);
    this.append(details);
    let loaded = false;
    details.ontoggle = async () => {
      if (!details.open || loaded) return;
      loaded = true;
      panel.textContent = t("جارٍ تحديد موقع الخادم…","Looking up the server…");
      try {
        const report = this.hasAttribute("report");
        const url = report ? new URL(location.href) : new URL("/api/evidence-host",location.origin);
        if (report) url.searchParams.set("view","location");
        else url.searchParams.set("host",this.getAttribute("host"));
        const response = await fetch(url,{referrerPolicy:"no-referrer"});
        if (!response.ok) throw Error();
        const meta = await response.json();
        const n = meta?.network;
        panel.textContent = [meta?.host, meta?.ip, n?.city, n?.region, n?.country, meta?.observedUTC].filter(Boolean).join(" · ");
        if (!Number.isFinite(n?.latitude) || !Number.isFinite(n?.longitude) || Math.abs(n.latitude)>90 || Math.abs(n.longitude)>180) {
          const p=document.createElement("p");p.textContent=t("لا تتوفر إحداثيات موثوقة لهذا الخادم.","No location coordinates are available for this server.");panel.append(p);return;
        }
        const lat=n.latitude, lon=n.longitude;
        const map=new URL("https://www.openstreetmap.org/export/embed.html");
        const bounded=(v,limit)=>Math.max(-limit,Math.min(limit,v));
        map.search=new URLSearchParams({bbox:[bounded(lon-.3,180),bounded(lat-.2,85),bounded(lon+.3,180),bounded(lat+.2,85)].join(","),layer:"mapnik",marker:lat+","+lon});
        const frame=document.createElement("iframe");
        frame.title=summary.textContent;frame.referrerPolicy="no-referrer";
        frame.src=map.href;frame.style.cssText="display:block;width:100%;height:250px;border:0;margin:8px 0;border-radius:10px";
        const note=document.createElement("p");
        note.textContent=t("المؤشر تقدير لموقع خادم الاستضافة أو شبكة التوزيع حسب عنوان IP. قد يبعد عن الخادم الفعلي.","The pin estimates the hosting server or CDN location from its IP address. Its physical location can differ.");
        const link=document.createElement("a");
        link.textContent=t("فتح الخريطة بالحجم الكامل","Open full map");
        link.href="https://www.openstreetmap.org/?mlat="+lat+"&mlon="+lon+"#map=9/"+lat+"/"+lon;
        link.target="_blank";link.rel="noopener noreferrer";link.style.color="inherit";
        const street=document.createElement("details");
        const caption=document.createElement("summary");
        caption.textContent=t("الخريطة التفصيلية","Detailed map");
        caption.style.cssText="cursor:pointer;padding:10px 0;font-weight:600";
        street.append(caption);
        street.ontoggle=()=>{if(street.open && !frame.isConnected) street.append(frame,link);};
        panel.append(street,note);
        try {
          const {serverGlobe}=await import("/server-globe.mjs");
          const globe=await serverGlobe(lat,lon,t);
          panel.insertBefore(globe,street);
        } catch {street.open=true;}
      } catch {
        panel.textContent=t("تعذّر تحميل بيانات الخادم. أغلق الخريطة وافتحها لإعادة المحاولة.","Server lookup failed. Close and reopen the map to retry.");
        loaded=false;
      }
    };
    if(this.hasAttribute("expanded")) details.open=true;
  }
}
customElements.define("host-location",HostLocation);
