// Order within each message: Arabic title, English title, Arabic advice, English advice.
(() => {
  const day = 86400000;
  const messages = {
    union: ["عروض وتذاكر عيد الاتحاد؟ تأكّد قبل ما تدفع", "Eid Al Etihad offers and tickets",
      "إذا وصلك عرض أو رابط تذاكر لفعاليات عيد الاتحاد، افتح موقع المنظّم الرسمي وتأكد من السعر. وإذا طلبوا منك تدفع برابط منفصل، افحصه في راصّد أول.", "Buying tickets for Eid Al Etihad? Check the price on the organiser’s official site. If someone sends a separate payment link, check it in RASID first."],
    general: ["انتبه من روابط النصب", "Watch out for scam links", "إذا وصلك رابط ما تعرف مصدره، افحصه في راصّد قبل لا تفتحه.", "Check unfamiliar links in RASID before opening them."],
    sports: ["تذكرة مباراة أو رابط بث مجاني؟", "Match tickets or a free stream?", "اشتر التذاكر من المنظّم الرسمي، وافحص روابط البث قبل لا تفتحها.", "Buy tickets from the official organiser and check streaming links before opening them."],
    events: ["تذاكر الفورمولا 1 والحفلات", "Formula 1 and concert tickets", "تأكد من البائع الرسمي. السعر الرخيص وايد أو طلب الدفع برابط خارجي يستاهل التحقق.", "Verify the official seller. Check unusually low prices and separate payment links before paying."],
    sale: ["عروض الجمعة البيضاء؟ افحص الرابط", "Check White Friday deals", "إذا السعر أرخص من المعقول، افتح المتجر الرسمي وتأكد من العرض قبل الدفع.", "If a price seems unusually low, check the offer directly with the official retailer before paying."],
    ramadan: ["انتبه من روابط التبرعات والعيديات", "Check donation and Eid gift links", "تبرع عن طريق الجهات المعتمدة، وانتبه من روابط العيديات اللي توصلك من أرقام غريبة.", "Donate through authorised organisations and check gift links from unfamiliar numbers."],
    hajj: ["احذر حملات الحج والعمرة الوهمية", "Verify Hajj and Umrah offers", "تأكد من الحملة والتصريح عند الجهة الرسمية قبل لا تدفع أو ترسل بياناتك.", "Confirm the operator and permit through official channels before paying or sending personal details."],
    government: ["رسالة مخالفة أو تجديد؟ تأكّد", "A fine or renewal message?", "افتح تطبيق الجهة الحكومية أو موقعها الرسمي بنفسك وتأكد من الطلب قبل الدفع.", "Open the government authority’s official app or website yourself to verify the request."],
    delivery: ["رسالة تقول طردك محجوز؟", "A message saying your parcel is on hold?", "قبل لا تدفع أي رسوم، تأكد من حالة الشحنة في تطبيق شركة التوصيل.", "Check your shipment in the courier’s own app before paying a release or delivery fee."],
    bank: ["رسالة تقول حسابك موقوف؟", "A message saying your bank account is frozen?", "لا تشارك رمز التحقق. اتصل بالبنك على رقمه الرسمي وتأكد من الرسالة.", "Keep your verification code private. Call the bank on its official number to check the message."],
    prize: ["ربحت جائزة من مسابقة ما شاركت فيها؟", "A prize from a competition you never entered?", "لا تفتح رابط استلام الجائزة ولا ترسل بياناتك.", "Avoid the claim link and keep your personal details private."],
    check: ["تنبيه من راصّد", "RASID reminder", "لا تفتح الرابط قبل ما تفحصه.", "Check the link before opening it."],
    suspect: ["رابط مشبوه؟", "Suspicious link?", "افحصه في راصّد أول.", "Check it in RASID first."],
    code: ["حافظ على رمز التحقق", "Protect your verification code", "لا تشارك رمز التحقق مع أي أحد.", "Never share your verification code."]
  };
  const regular = ["general","sports","government","check","delivery","events","bank","suspect","prize","code"];
  function dateParts(date, calendar) {
    const parts = new Intl.DateTimeFormat("en-US", { timeZone:"Asia/Dubai", calendar, month:"numeric", day:"numeric" }).formatToParts(date);
    return ["month","day"].map(k => Number(parts.find(p => p.type === k).value));
  }
  function current(date) {
    const [month, d] = dateParts(date,"gregory");
    if ((month === 11 && d >= 24) || (month === 12 && d <= 3)) return "union";
    if (month === 11 && d >= 15) return "sale";
    const [hm, hd] = dateParts(date,"islamic-umalqura");
    if (hm === 9 || (hm === 10 && hd <= 3)) return "ramadan";
    if (hm === 12 && hd <= 13) return "hajj";
    return regular[Math.floor((date.getTime() + 4*3600000)/day) % regular.length];
  }
  let timer;
  function show() {
    clearTimeout(timer);
    const input = document.querySelector("#q");
    if (!input || document.hidden || !localStorage.rasid_token) return;
    const profile = JSON.parse(localStorage.rasid_user || "null");
    if (!profile) return;
    const key = "rasid_notice_last:" + (profile.email || profile.name);
    const now = Date.now(), last = Number(localStorage.getItem(key)) || 0;
    const next = last + day - now;
    const switched = sessionStorage.getItem("rasid_notice_switch") === document.documentElement.lang;
    if (!switched && next > 0 && last <= now) { timer = setTimeout(show, next + 100); return; }
    if (document.querySelector("#safety-notice") || input.value || document.activeElement === input || document.querySelector("#out")?.childElementCount) return;
    const en = document.documentElement.lang === "en";
    const msg = messages[current(new Date(now))];
    const dialog = document.createElement("dialog");
    dialog.id = "safety-notice";
    dialog.setAttribute("aria-labelledby","notice-title");
    dialog.setAttribute("aria-describedby","notice-advice");
    const title = document.createElement("h2"), advice = document.createElement("p");
    title.id = "notice-title"; title.textContent = msg[en ? 1 : 0];
    advice.id = "notice-advice"; advice.textContent = msg[en ? 3 : 2];
    const actions = document.createElement("div");
    for (const [label, check] of [[en ? "Got it" : "تم",false],[en ? "Check a link" : "افحص رابط",true]]) {
      const button = document.createElement("button");
      button.type="button"; button.className=check ? "primary" : "ghost"; button.textContent=label;
      button.onclick=()=>{dialog.close();if(check) input.focus();};
      actions.append(button);
    }
    dialog.append(title,advice,actions);
    dialog.addEventListener("close",()=>dialog.remove(),{once:true});
    document.body.append(dialog); dialog.showModal();
    sessionStorage.removeItem("rasid_notice_switch");
    localStorage.setItem(key,String(now));
    window.webkit?.messageHandlers?.rasidApp?.postMessage({signedIn:true,safetyNoticeSeen:true, noticeTitle:title.textContent, noticeAdvice:advice.textContent});
    timer=setTimeout(show,day+100);
  }
  document.addEventListener("visibilitychange",()=>{if(!document.hidden) show();});
  window.showSafetyNotice=show;
})();
