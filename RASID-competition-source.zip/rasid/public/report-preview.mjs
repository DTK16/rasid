const status=document.querySelector('[role="status"]');
try {
  const pdfjs=await import('./vendor/pdfjs/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc='/vendor/pdfjs/pdf.worker.min.mjs';
  const address=new URL(location.href);
  address.searchParams.set('view','pdf');
  const pdf=await pdfjs.getDocument({url:address.href,isEvalSupported:false,useSystemFonts:true}).promise;
  const pages=document.querySelector('main');
  for(let n=1;n<=pdf.numPages;n++){
    const page=await pdf.getPage(n), figure=document.createElement('figure'), canvas=document.createElement('canvas');
    const natural=page.getViewport({scale:1});
    const width=Math.min(850,Math.max(320,pages.clientWidth));
    const viewport=page.getViewport({scale:width/natural.width*Math.min(2,window.devicePixelRatio||1)});
    canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
    const caption=document.createElement('figcaption');caption.textContent='Page '+n+' of '+pdf.numPages;
    figure.append(canvas,caption);pages.append(figure);
    await page.render({canvas,canvasContext:canvas.getContext('2d'),viewport}).promise;
    const copy=await page.getTextContent();canvas.setAttribute('role','img');canvas.setAttribute('aria-label',copy.items.map(item=>item.str||'').join(' '));
    if(n===1)status.hidden=true;
  }
} catch {
  status.hidden=false;status.textContent='Your browser could not display the preview. Use Open PDF to view the original.';
}
