//  ViewController.swift — Rasid · راصد (iPhone host app)
//
//  Replaces the converter's template ViewController for the iOS app target.
//  Shows RasidOnboardingView instead of the template's Main.html page.

import UIKit
import SwiftUI
import WebKit

class ViewController: UIViewController {

    // The template storyboard still connects a web view to this outlet. It stays declared so the
    // storyboard loads without a crash, but it is hidden and never used.
    @IBOutlet var webView: WKWebView!

    private var host: UIHostingController<RasidOnboardingView>?
    private var lastDirection: UISemanticContentAttribute?

    override func viewDidLoad() {
        super.viewDidLoad()
        webView?.isHidden = true
        view.backgroundColor = .systemGroupedBackground

        refreshDirection()
        NotificationCenter.default.addObserver(self, selector: #selector(refreshDirection),
                                               name: UserDefaults.didChangeNotification, object: nil)
    }

    @objc private func refreshDirection() {
        overrideUserInterfaceStyle = UIUserInterfaceStyle(rawValue: UserDefaults.standard.integer(forKey: "rasid_appearance")) ?? .unspecified
        let language = UserDefaults.standard.string(forKey: "rasid_lang") ?? Locale.preferredLanguages.first ?? "en"
        let direction: UISemanticContentAttribute = language.hasPrefix("ar") ? .forceRightToLeft : .forceLeftToRight
        guard lastDirection != direction else { return }
        lastDirection = direction
        view.semanticContentAttribute = direction
        if let host {
            host.view.semanticContentAttribute = direction
            host.view.setNeedsLayout()
            return
        }
        let host = UIHostingController(rootView: RasidOnboardingView())
        self.host = host
        host.view.semanticContentAttribute = direction
        addChild(host)
        host.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.topAnchor.constraint(equalTo: view.topAnchor),
            host.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        host.didMove(toParent: self)
    }
}
