// Rasid Safari extension · runs at the very start of every page.
// The native app supplies the session and protection preference.
// 2) On any other site, when protection is on: stops the page, checks it with Rasid,
//    reloads it only if Rasid says it is safe, otherwise shows a block screen.
(function () {
  "use strict";
  var RASID_ORIGIN = "https://rasid-link-checker.netlify.app";
  var EN = false; // follows the language chosen on the Rasid site
  var T = function (ar, en) { return EN ? en : ar; };

  if (location.origin === RASID_ORIGIN) {
    if (location.pathname === "/safari-check.html" && window.top === window) {
      function checkExtension() {
        browser.runtime.sendMessage({type:"status",url:location.href}).then(
          state=>{document.documentElement.dataset.rasidExtension=state?.active ? "active" : "off";},
          ()=>{document.documentElement.dataset.rasidExtension="error";}
        );
      }
      if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",checkExtension,{once:true});
      else checkExtension();
    }
    if (window.top === window) document.addEventListener("click", event => {
      const lang = event.target.closest?.(".langbar button[data-lang]")?.dataset.lang;
      if (lang === "ar" || lang === "en") browser.runtime.sendMessage({type:"setLanguage",lang}).catch(()=>{});
    }, true);
    return;
  }
  if (window.top !== window) return;
  if (!/^https?:$/.test(location.protocol)) return;
  browser.runtime.sendMessage({ type: "status", url: location.href }).then(function (st) {
    if (!st || !st.active) return; // protection is off or not signed in: do nothing
    EN = st.lang === "en";
    if (st.continued) return;
    protectCardForms();
    if (st.known) markSearchResults();
    if (st.known) { // already checked as safe in the last 30 minutes
      prepareInternalLinks();
      toast(T("ما ظهرت مؤشرات خطر في فحص هذا الرابط.", "No warning signs were found in the scan of this link."));
      return;
    }
    window.stop();                  // nothing on this page loads until Rasid has checked it
    var ui = screen("#0f2a44");
    ui.add("div", "font-size:54px;margin-bottom:8px", "⌛");
    ui.add("div", "font-size:26px;font-weight:800", T("راصد يرصد الموقع…", "Rasid is checking this site…"));
    ui.add("div", "font-size:14px;opacity:.85;margin-top:4px", T("لن يُفتح الموقع قبل أن يتأكد راصد منه", "It will not open until Rasid has checked it"));
    ui.add("div", "font-size:13px;opacity:.75;margin-top:12px;word-break:break-all;direction:ltr", location.hostname);

    browser.runtime.sendMessage({ type: "check", url: location.href }).then(function (r) {
      if (r && (r.allow || r.inactive)) {
        location.reload();
      } else {
        if (r?.level === "suspicious") {
          browser.runtime.sendMessage({type:"showWarning", url:location.href});
        }
        blocked(r || {});
      }
    }, function () { blocked({}); });
  }, function () {});

  function markSearchResults() {
    const google = /^(?:www\.)?google\.(?:com|ae)$/i;
    if (!google.test(location.hostname) || location.pathname !== "/search") return;
    const services = [
      { name: /\bRTA\b|هيئة الطرق والمواصلات/i, hostName: /(?:^|[.-])rta(?:[.-]|$)/i, domains: ["rta.ae"] },
      { name: /\bTAMM\b|منص[ةه]\s+تـ*م|تـ*م[ّ]?\s+أبو\s*ظبي/i, hostName: /(?:^|[.-])tamm(?:[.-]|$)/i, domains: ["tamm.abudhabi"] },
      { name: /Dubai Police|شرطة دبي/i, hostName: /dubai[.-]?police/i, domains: ["dubaipolice.gov.ae"] },
      { name: /Abu Dhabi Police|شرطة أبوظبي|شرطة أبو ظبي/i, hostName: /adpolice|abudhabi[.-]?police/i, domains: ["adpolice.gov.ae"] }
    ];
    const payment = /\b(?:pay|payment|fine|fines|checkout)\b|دفع|سداد|مخالف/i;
    const notices = new Map();
    function review() {
      const current = new Set();
      for (const heading of document.querySelectorAll('h3, [role="heading"]')) {
        const anchor = heading.closest("a[href]") || heading.querySelector("a[href]");
        if (!anchor) continue;
        let url;
        try {
          url = new URL(anchor.href);
          if (google.test(url.hostname) && ["/url", "/aclk", "/pagead/aclk"].includes(url.pathname)) {
            const target = url.searchParams.get("adurl") || url.searchParams.get("q") || url.searchParams.get("url");
            url = new URL(target);
          }
        } catch { continue; }
        if (!/^https?:$/.test(url.protocol)) continue;
        const host = url.hostname.toLowerCase().replace(/\.$/, "");
        const title = heading.textContent;
        const service = services.find(s => s.name.test(title));
        if (!service || !payment.test(title) || !(service.hostName.test(host) || /(?:^|[.-])(?:pay|fines?|checkout|payment)(?:[.-]|$)/i.test(host))) continue;
        if (services.some(s => s.domains.some(d => host === d || host.endsWith("." + d))) || host.endsWith(".gov.ae")) continue;
        current.add(anchor);
        let note = notices.get(anchor);
        if (!note) {
          note = document.createElement("div");
          note.dir = EN ? "ltr" : "rtl";
          note.style.cssText = "margin:4px 0 10px;padding:7px 10px;border-inline-start:3px solid #ab6500;border-radius:5px;background:#fff3d6;color:#542e00;font:500 14px/1.45 system-ui;overflow-wrap:anywhere";
          notices.set(anchor, note);
        }
        const expected = service.domains[0];
        const reason = T("راصّد: تحقّق قبل الدفع. عنوان الوجهة " + host + " يختلف عن نطاق الجهة " + expected + ".",
          "Rasid: check before paying. The destination " + host + " differs from the service’s domain " + expected + ".");
        if (note.textContent !== reason) note.textContent = reason;
        if (anchor.nextElementSibling !== note) anchor.after(note);
      }
      for (const [anchor, note] of notices) {
        if (!current.has(anchor)) { note.remove(); notices.delete(anchor); }
      }
    }
    let queued = false;
    const observer = new MutationObserver(() => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; review(); });
    });
    observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["href","role"] });
    review();
  }

  // Inspect field metadata and the submission destination, never payment values.
  function protectCardForms() {
    const card = 'input[autocomplete~="cc-number" i],input[autocomplete~="cc-csc" i]';
    function stopInsecurePayment(event) {
      const target = event.target;
      const submitting = event.type === "submit";
      const form = submitting ? target : target.form;
      if (submitting) {
        if (!(form instanceof HTMLFormElement) ||
            !Array.from(form.elements).some(element => element.matches(card))) return;
      } else if (!target.matches?.(card)) return;
      const submitter = submitting ? event.submitter : null;
      const action = submitter?.hasAttribute("formaction") ? submitter.getAttribute("formaction") : form?.getAttribute("action");
      const destination = new URL(action || location.href, document.baseURI);
      if (location.protocol === "https:" && destination.protocol === "https:") return;
      event.preventDefault();
      event.stopImmediatePropagation();
      window.stop();
      blocked({
        reason_en: "This checkout uses an insecure connection for card details.",
        reason_ar: "تستخدم صفحة الدفع اتصالاً غير آمن لبيانات البطاقة."
      });
    }
    for (const type of ["focusin", "beforeinput", "submit"]) {
      window.addEventListener(type, stopInsecurePayment, true);
    }
  }

  // Keep the current page visible while checking ordinary same-site navigation.
  function prepareInternalLinks() {
    let navigation = 0;
    let notice;
    window.addEventListener("click", async function (event) {
      if (!event.isTrusted || event.defaultPrevented || event.button !== 0 ||
          event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor = event.target.closest?.("a[href]");
      if (!anchor || anchor.hasAttribute("download") || anchor.hasAttribute("onclick") ||
          (anchor.target && anchor.target !== "_self") || document.querySelector("base[target]")) return;
      const url = new URL(anchor.href, location.href);
      if (url.origin !== location.origin || url.pathname + url.search === location.pathname + location.search) return;
      event.preventDefault();
      const request = ++navigation;
      const from = location.href;
      notice?.remove();
      const timer = setTimeout(() => {
        if (request !== navigation || location.href !== from) return;
        notice = document.createElement("div");
        notice.setAttribute("role", "status");
        notice.style.cssText = "position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#163448;color:white;border-radius:18px;padding:8px 14px;font:500 14px system-ui;pointer-events:none";
        notice.textContent = T("راصد يفحص الرابط…", "Checking link…");
        document.body.append(notice);
      }, 350);
      try {
        // The destination page reuses only a successful exact-URL verdict.
        // Other results use the existing destination warning and override flow.
        await browser.runtime.sendMessage({type:"prepare", url:url.href});
      } catch {
        // The destination still runs its normal protection check.
      } finally {
        clearTimeout(timer);
        if (request === navigation) {
          notice?.remove();
          if (location.href === from) location.assign(url.href);
        }
      }
    });
  }

  // Small green note at the top of a page Rasid let through.
  function toast(text) {
    var show = function () {
      if (!document.body) return;
      var t = document.createElement("div");
      rasidFeedback(t, "safe", text, EN);
      t.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#14532d;color:#fff;padding:10px 16px;border-radius:999px;font:600 14px -apple-system,system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);width:max-content;max-width:85vw;border-radius:16px;text-align:center";
      document.body.appendChild(t);

      setTimeout(function () { if (t.contains(document.activeElement)) return; if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) t.style.transition = "opacity .6s"; t.style.opacity = "0"; }, 9500);
      setTimeout(function () { if (!t.contains(document.activeElement)) t.remove(); }, 10000);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
  }

  let currentWarning;
  async function refreshWarning() {
    if (!currentWarning || document.hidden) return;
    try {
      const {lang} = await browser.runtime.sendMessage({type:"status",url:location.href});
      if ((lang === "en" || lang === "ar") && EN !== (lang === "en")) {
        EN = lang === "en";
        blocked(currentWarning);
      }
    } catch {}
  }
  window.addEventListener("focus", refreshWarning);
  document.addEventListener("visibilitychange", refreshWarning);
  function blocked(r) {
    currentWarning = r;
    document.documentElement.lang = EN ? "en" : "ar";
    document.documentElement.dir = EN ? "ltr" : "rtl";
    var ui = screen("#7a1610");
    const result = ui.add("div", "max-width:460px;padding:16px", "");
    rasidFeedback(result, r.level, EN ? (r.reason_en || "RASID could not verify this site.") : (r.reason_ar || "تعذّر على راصّد التحقق من الموقع."), EN);
    ui.add("div", "font-size:14px;direction:ltr", location.hostname);
    if (r.level === "dangerous") browser.runtime.sendMessage({type:"dangerDisplayed",url:location.href}).then(ok => {
      ui.add("div","margin-top:8px",ok ? T("سُجّل التحذير في راصّد","Warning recorded in RASID") : T("تعذّر حفظ التحذير","Warning could not be recorded"));
    }).catch(()=>{});
    var back = ui.add("button", "margin-top:22px;min-height:50px;padding:10px 26px;border:none;border-radius:12px;background:#fff;color:#0f2a44;font-size:17px;font-weight:700", T("↩ رجوع", "↩ Go back"));
    back.addEventListener("click", function () { if (history.length > 1) history.back(); else location.replace("about:blank"); });
    const place=ui.add("div","margin-top:8px",T("جارٍ تحديد موقع الخادم…","Looking up the server…"));
    browser.runtime.sendMessage({type:"serverLocation",url:location.href}).then(value=>{
      place.textContent=value ? T("موقع الخادم التقريبي: ","Approximate server location: ")+value : T("موقع الخادم غير متوفر","Server location unavailable");
    },()=>{place.textContent=T("موقع الخادم غير متوفر","Server location unavailable");});
    const mapLink = ui.add("a","color:white;margin-top:10px",T("خريطة خادم الموقع","Website server map"));
    mapLink.href = "https://rasid-link-checker.netlify.app/server-map.html?" + new URLSearchParams({host:location.hostname,lang:EN?"en":"ar"});
    mapLink.target="_blank"; mapLink.rel="noopener noreferrer";
    var rep = ui.add("button", "margin-top:10px;min-height:46px;padding:10px 22px;border:1px solid rgba(255,255,255,.6);border-radius:12px;background:transparent;color:#fff;font-size:15px;font-weight:600", T("إرسال بلاغ إلى راصّد", "Report to RASID"));
    rep.addEventListener("click", function () { browser.runtime.sendMessage({type:"prepareEvidence", url:location.href, lang:EN?"en":"ar", level:r.level, score:r.score, reason_en:r.reason_en, reason_ar:r.reason_ar}); });
  }

  function screen(bg) {
    var root = document.documentElement;
    while (root.firstChild) root.removeChild(root.firstChild);
    var body = document.createElement("body");
    root.appendChild(body);
    root.setAttribute("dir", EN ? "ltr" : "rtl");
    var box = document.createElement("div");
    box.style.cssText = "position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;color:#fff;font-family:-apple-system,system-ui,sans-serif;background:" + bg;
    body.style.cssText = "margin:0";
    body.appendChild(box);
    return {
      add: function (tag, css, text) {
        var n = document.createElement(tag);
        n.style.cssText = css;
        n.textContent = text.replaceAll("—", "·");
        box.appendChild(n);
        return n;
      },
    };
  }
})();
