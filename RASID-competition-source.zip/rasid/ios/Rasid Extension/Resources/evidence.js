// Clicking Report authorizes sending the warning screenshot to the RASID report service.
async function openEvidence({en, element, submitReport}) {
  const T = (ar, english) => en ? english : ar;
  const requestId = crypto.randomUUID();
  const dialog = document.createElement("dialog");
  dialog.dir = en ? "ltr" : "rtl";
  dialog.style.cssText = "max-width:min(92vw,32rem);max-height:85vh;overflow:auto;border:0;border-radius:18px;padding:24px;font:16px system-ui;color:#18283a;background:white";
  function add(tag, text) {
    const item = document.createElement(tag);
    item.textContent = text;
    dialog.append(item);
    return item;
  }
  const title = add("h2", T("إرسال بلاغ","Send incident report"));
  dialog.setAttribute("aria-label",title.textContent);
  add("p", T("يُرسل تقرير الأدلة إلى دعم راصّد: support.rasid@gmail.com","The evidence report goes to RASID Support at support.rasid@gmail.com."));
  const status = add("p", T("جاري تجهيز الأدلة وإرسال رابط البلاغ…","Preparing evidence and sending the report link…"));
  status.setAttribute("role","status");
  const retry = add("button",T("إعادة المحاولة","Retry"));
  const close = add("button",T("إلغاء","Cancel"));
  for(const btn of [retry,close]) btn.style.cssText="margin:10px 4px;padding:10px 16px;min-height:44px;color:#fff;background:#214f5a;border:0;border-radius:9px";
  retry.hidden=true;
  close.onclick=()=>dialog.close();
  dialog.addEventListener("close",()=>dialog.remove(),{once:true});
  document.body.append(dialog);dialog.showModal();
  async function send() {
    close.textContent=T("إلغاء","Cancel");
    retry.hidden=true;
    status.textContent=T("جاري إرسال رابط البلاغ…","Sending the report link…");
    try {
      let jpeg;
      try {
        const scale=Math.min(1,900/Math.max(1,element.clientWidth),1600/Math.max(1,element.scrollHeight));
        const screen=await html2canvas(element,{scale,logging:false,ignoreElements:n=>n===dialog || n.tagName==="IFRAME"});
        for(const quality of [0.72,0.5,0.3]){
          jpeg=screen.toDataURL("image/jpeg",quality);
          if(jpeg.startsWith("data:image/jpeg;base64,") && jpeg.length<=700000) break;
        }
        if(!jpeg.startsWith("data:image/jpeg;base64,") || jpeg.length>700000) throw Error();
      } catch {throw Error("screenshot");}
      if(!dialog.open) return;
      const receipt=await submitReport(jpeg,requestId);
      if(!dialog.open) return;
      if(receipt?.sent!==true && receipt!==true) throw Error(receipt?.error || "delivery");
      close.textContent=T("تم","Done");
      status.textContent=T("قبلت خدمة البريد إرسال بلاغك إلى دعم راصّد.","The mail service accepted the report for RASID Support.");
    } catch(error) {
      if(!dialog.open) return;
      close.textContent=T("إغلاق","Close");
      const messages={
        auth:["انتهت جلسة راصّد. أعد فتح التطبيق وسجّل الدخول أو تابع كضيف.","Your session expired. Reopen RASID and sign in or continue as a guest."],
        screenshot:["تعذّر التقاط صورة التحذير. أعد فتح التحذير وحاول مجدداً.","The warning screenshot could not be captured. Reopen the warning and retry."],
        unconfirmed:["تعذّر تأكيد تصنيف هذا الرابط كمشبوه أو خطير عند إعادة فحصه.","The server rechecked this link and could not confirm a suspicious or dangerous verdict."],
        submission_pending:["تأكيد خدمة البريد ما زال معلّقاً.","Mail submission is pending confirmation."],
        mail_unconfigured:["خدمة بريد راصّد غير مهيأة.","The RASID mail service is not configured."],
        rate_limit:["طلبات كثيرة. حاول بعد دقيقة.","Too many requests. Retry in a minute."],
        mail_rejected:["رفضت خدمة البريد إرسال البلاغ.","The mail provider rejected this submission."],
        mail_failed:["تعذّر إرسال البلاغ عبر خدمة البريد.","The mail provider could not send this report."],
        report_failed:["تعذّر على الخادم تجهيز البلاغ أو إرساله.","The server could not prepare or send the report."],
        mail_unconfirmed:["لم تؤكد خدمة البريد قبول البلاغ.","The mail provider has not confirmed acceptance."]
      };
      status.textContent=T(...(messages[error.message] || ["تعذّر تأكيد الإرسال. تحقق من الاتصال ثم أعد المحاولة.","Delivery could not be confirmed. Check your connection and retry."]));
      retry.hidden=false;
    }
  }
  retry.onclick=send;
  await send();
}
