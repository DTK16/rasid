// Result controls run in the Safari extension's isolated world.
function rasidFeedback(container, level, reason, en) {
  const labels = {
    safe: ["✓", "آمن", "Safe"],
    suspicious: ["⚠", "مشبوه", "Suspicious"],
    dangerous: ["⛔", "خطير", "Dangerous"],
    unknown: ["?", "تعذّر التحقق", "Could not verify"]
  };
  const [icon, ar, english] = labels[level] || labels.unknown;
  const title = en ? english : ar;
  const message = title + ". " + reason;
  const heading = document.createElement("strong");
  heading.textContent = icon + " " + title;
  heading.style.cssText = "display:block;font:bold 24px system-ui;color:inherit";
  const detail = document.createElement("span");
  detail.textContent = reason;
  detail.style.cssText = "display:block;font:16px/1.45 system-ui";
  container.lang = en ? "en" : "ar";
  container.dir = en ? "ltr" : "rtl";
  container.setAttribute("role", "status");
  container.setAttribute("aria-atomic", "true");
  container.replaceChildren(heading, detail);
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return;
  const speak = () => {
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = en ? "en-US" : "ar-AE";
    window.speechSynthesis.speak(utterance);
  };
  const listen = document.createElement("button");
  listen.type = "button";
  listen.textContent = en ? "Listen" : "استمع";
  listen.style.cssText = "margin:6px;padding:4px 14px;min-height:44px;border:1px solid currentColor;border-radius:10px;background:transparent;color:inherit;font:600 16px system-ui";
  listen.onclick = () => { window.speechSynthesis.cancel(); speak(); };
  container.append(listen);
  if (!document.hidden) speak();
}
