// Rasid block screen (inside the extension). Shows why the link was stopped, in the language chosen on
// the Rasid site. Text is set with textContent only.
(function () {
  var q = new URLSearchParams(location.search);
  const warningTime = new Date().toISOString();
  var en = q.get("lang") === "en";
  var T = function (ar, e) { return en ? e : ar; };
  var host = "";
  try { host = new URL(q.get("u") || "").hostname; } catch (e) {}
  var set = function (id, text) { document.getElementById(id).textContent = text.replaceAll("—", "·"); };
  let serverPlace, lastSpokenLanguage;
  browser.runtime.sendMessage({type:"serverLocation",url:q.get("u")}).then(value=>{serverPlace=value || "";render();},()=>{serverPlace="";render();});
  function render() {
    document.documentElement.lang = en ? "en" : "ar";
    document.documentElement.dir = en ? "ltr" : "rtl";
  set("title", T("تم منع الموقع", "Site blocked"));
  set("sub", T("منع راصد هذا الموقع لحمايتك", "Rasid blocked this site to protect you"));
  if (q.get("level") === "dangerous") set("title", T("رابط خطير", "Dangerous link"));
  if (q.get("level") === "suspicious") {
    set("title", T("رابط مشبوه", "Suspicious link"));
    set("sub", T("راجع السبب قبل المتابعة", "Review the warning before continuing"));
    const button = document.getElementById("continue");
    button.hidden = false;
    button.textContent = T("فتح على أي حال", "Open anyway");
    button.onclick = async () => {
      button.disabled = true;
      try {
        const tab = await browser.tabs.getCurrent().catch(()=>null);
        if (await browser.runtime.sendMessage({type:"continue",url:q.get("u"),tabId:tab?.id})) return;
      } catch {}
      button.disabled = false;
      set("why", T("تعذّر فتح الموقع. أعد فحص الرابط قبل المتابعة.", "Could not open this site. Check the link again before continuing."));
    };
  }
  set("host", host);
  set("server-place",serverPlace === undefined ? T("جارٍ تحديد موقع الخادم…","Looking up the server…") : serverPlace ? T("موقع الخادم التقريبي: ","Approximate server location: ")+serverPlace : T("موقع الخادم غير متوفر","Server location unavailable"));
  set("host-map",T("خريطة خادم الموقع","Website server map"));
  document.getElementById("host-map").href="https://rasid-link-checker.netlify.app/server-map.html?"+new URLSearchParams({host,lang:en?"en":"ar"});
  set("why", en
    ? (q.get("en") || "Could not verify this site, so it was blocked as a precaution") + (q.get("se") ? " · " + q.get("se") : "")
    : (q.get("ar") || "تعذّر التحقق من الموقع، فتم منعه احتياطاً") + (q.get("s") ? " · " + q.get("s") : ""));
  if (lastSpokenLanguage !== en) {
    lastSpokenLanguage = en;
    const reason = document.getElementById("why");
    rasidFeedback(document.getElementById("accessible-result"), q.get("level"), reason.textContent, en);
    document.getElementById("title").hidden = true;
    reason.hidden = true;
  }
  set("close", T("✕ إغلاق الصفحة", "✕ Close this page"));
  set("report", T("إرسال بلاغ إلى راصّد", "Report to RASID"));
  }
  render();
  async function updateLanguage() {
    try {
      const state = await browser.runtime.sendMessage({type:"status"});
      if (state?.lang === "ar" || state?.lang === "en") {
        en = state.lang === "en";
        render();
      }
    } catch {}
  }
  updateLanguage();
  window.addEventListener("focus",updateLanguage);
  document.addEventListener("visibilitychange",()=>{ if(!document.hidden) updateLanguage(); });
  // Preserve automatic demo recording when a dangerous warning first appears.
  let receipt;
  function record() {
    if (!receipt) receipt = browser.runtime.sendMessage({type:"dangerDisplayed",url:q.get("u")}).then(ok => {
      if (!ok) receipt = null;
      return ok === true;
    }).catch(()=>{receipt=null;return false;});
    return receipt;
  }
  if(q.get("level")==="dangerous") record();
  document.getElementById("close").addEventListener("click", function () {
    browser.tabs.getCurrent().then(function (t) { return browser.tabs.remove(t.id); }).catch(function () { location.replace("about:blank"); });
  });
  document.getElementById("report").addEventListener("click", function () {
    openEvidence({host, level:q.get("level"), score:q.get("score") ? Number(q.get("score")) : null, reason:q.get("en"), time:warningTime, en, element:document.body, submitReport:(screenshot,requestId)=>browser.runtime.sendMessage({type:"emailReport",url:q.get("u"),screenshot,requestId})});
  });
  if(q.get("prepare")==="1") requestAnimationFrame(()=>document.getElementById("report").click());
})();
