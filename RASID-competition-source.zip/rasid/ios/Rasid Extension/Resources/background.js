// Rasid Safari extension — background.
// Keeps the user's Rasid sign-in and protection switch (copied from the Rasid site), asks the Rasid
// server whether a page may open, and remembers sites already checked as safe (for 30 minutes) so
// moving around the same site, or a redirect like bbc.com → www.bbc.com, does not trigger a new check.
// Anything uncertain is blocked (fail-safe).

const RASID = "https://rasid-link-checker.netlify.app";
const SAFE_TTL_MS = 30 * 60 * 1000;
// Cache exact URLs in extension memory only for the current signed-in session.
const safe = new Map();
const pending = new Map();
const warnings = new Map();
const exceptions = new Map();
const VISIT_MS = 5 * 60 * 1000;
const visitKey = id => "rasidVisit:" + id;
async function ownerKey(token) {
  const bytes = new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(token)));
  return Array.from(bytes,n=>n.toString(16).padStart(2,"0")).join("");
}
async function clearVisit(id) {
  exceptions.delete(id);
  await browser.storage.session?.remove(visitKey(id));
}
async function visitApplies(id, url, token) {
  if (id == null || !token || !/^https?:\/\//i.test(url || "")) return false;
  const key = visitKey(id);
  const visit = exceptions.get(id) || (await browser.storage.session?.get(key))?.[key];
  return !!visit && visit.until > Date.now() && visit.origin === new URL(url).origin && visit.owner === await ownerKey(token);
}
browser.tabs.onRemoved.addListener(id => { warnings.delete(id); clearVisit(id).catch(()=>{}); });
browser.webNavigation.onCommitted.addListener(async event => {
  if (event.frameId !== 0) return;
  const key=visitKey(event.tabId);
  const visit=exceptions.get(event.tabId) || (await browser.storage.session?.get(key))?.[key];
  if (visit && new URL(event.url).origin !== visit.origin) await clearVisit(event.tabId);
});
let activeToken = null;

async function getState() {
  const state = await browser.runtime.sendNativeMessage("ae.rasid.Rasid", {type: "state"});
  const token = state.protect ? state.token : null;
  if (activeToken !== token) {
    warnings.clear();
    exceptions.clear();
    pending.clear();
    safe.clear();
    activeToken = token;
  }
  return state;
}

function checkOnce(url, token) {
  if (!pending.has(url)) {
    const job = checkUrl(url, token).then(result => {
      if (result.allow && activeToken === token) {
        if (safe.size >= 512) safe.delete(safe.keys().next().value);
        safe.set(url, Date.now() + SAFE_TTL_MS);
      }
      return result;
    }).finally(() => { if (pending.get(url) === job) pending.delete(url); });
    pending.set(url, job);
  }
  return pending.get(url);
}

async function checkUrl(url, token) {
  try {
    const res = await fetch(RASID + "/api/check", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ url, mode: "gate" }),
    });
    const j = await res.json().catch(() => ({}));
    if (res.status === 401) return { allow: false, login: true, reason_ar: "سجّل الدخول إلى راصد من جديد", reason_en: "Sign in to Rasid again" };
    const g = j.gate || {};
    return {
      allow: !!g.allow,
      score: j.verdict?.score,
      level: j.verdict ? j.verdict.level : null,
      reason_ar: g.reason_ar || j.error_ar || "تعذّر التحقق من الموقع، فتم منعه احتياطاً",
      reason_en: g.reason_en || j.error_en || "Could not verify this site, so it was blocked",
      summary_ar: j.ai && j.ai.summary_ar ? j.ai.summary_ar : null,
      summary_en: j.ai && j.ai.summary_en ? j.ai.summary_en : null,
    };
  } catch (e) {
    return { allow: false, reason_ar: "لا يوجد اتصال بخادم راصد، فتم منع الموقع احتياطاً", reason_en: "Could not reach Rasid, so the site was blocked as a precaution" };
  }
}

browser.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !msg.type) return;
  const id = sender.tab?.id;
  if (msg.type === "setLanguage" && sender.frameId === 0 && sender.url && new URL(sender.url).origin === RASID && ["ar","en"].includes(msg.lang)) {
    return browser.runtime.sendNativeMessage("ae.rasid.Rasid",{type:"setLanguage",lang:msg.lang});
  }
  if (msg.type === "continue" && sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html")) {
    return getState().then(async s => {
      const id = sender.tab?.id ?? msg.tabId;
      const page = new URL(sender.url);
      if (!Number.isInteger(id) || (sender.frameId != null && sender.frameId !== 0) || page.searchParams.get("level") !== "suspicious" ||
          page.searchParams.get("u") !== msg.url || !/^https?:\/\//i.test(msg.url)) return false;
      if ((await browser.tabs.get(id)).url !== sender.url) return false;
      if (s.protect && s.token) {
        // A suspended Safari worker can lose its warning record while the user reads it.
        if (warnings.get(id) !== msg.url) {
          const verdict = await checkOnce(msg.url, s.token);
          if (!verdict.allow && verdict.level !== "suspicious") return false;
        }
        if ((await browser.tabs.get(id)).url !== sender.url) return false;
        const visit = {origin:new URL(msg.url).origin, until:Date.now()+VISIT_MS, owner:await ownerKey(s.token)};
        exceptions.set(id,visit);
        await browser.storage.session?.set({[visitKey(id)]:visit});
      }
      warnings.delete(id);
      try {
        await browser.tabs.update(id,{url:msg.url});
        return true;
      } catch {
        await clearVisit(id);
        return false;
      }
    });
  }
  if (msg.type === "showWarning" && sender.url === msg.url && sender.frameId === 0) {
    recent.delete(id + " " + msg.url);
    return watch(id, msg.url);
  }
  if (msg.type === "serverLocation") {
    const fromWarning = sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html");
    if (!fromWarning && (sender.frameId !== 0 || sender.url !== msg.url)) return;
    let host;
    try {host = new URL(msg.url).hostname;} catch {return;}
    return fetch(RASID+"/api/evidence-host?host="+encodeURIComponent(host),{credentials:"omit"})
      .then(response => response.ok ? response.json() : null)
      .then(data => [data?.network?.city,data?.network?.country].filter(Boolean).join(", "))
      .catch(() => "");
  }
  if (msg.type === "status") {
    return getState().then(async (s) => {
      const active = !!(s.token && s.protect);
      const known = active && safe.get(msg.url) > Date.now();
      return { active, known, continued: active && await visitApplies(id,msg.url,s.token), lang: s.lang };
    });
  }
  if (msg.type === "emailReport" && sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html")) {
    if(new URL(sender.url).searchParams.get("u") !== msg.url) return Promise.resolve(false);
    return getState().then(async state=>{
      if(!state.protect || !state.token) return {sent:false,error:"auth"};
      const response=await fetch(RASID+"/api/demo/report-link",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+state.token},body:JSON.stringify({url:msg.url,screenshot:msg.screenshot,requestId:msg.requestId})});
      const data=await response.json().catch(()=>({}));
      return response.ok ? data : {sent:false,error:response.status===401?"auth":response.status===429?"rate_limit":response.status===413?"screenshot":data.error};
    });
  }
  if (msg.type === "prepareEvidence" && sender.frameId === 0 && sender.url === msg.url && id != null) {
    const q = new URLSearchParams({u:sender.url, level:msg.level || "", score:String(msg.score ?? ""), en:msg.reason_en || "", ar:msg.reason_ar || "", lang:msg.lang, prepare:"1"});
    return browser.tabs.update(id,{url:browser.runtime.getURL("blocked.html")+"?"+q});
  }
  if (msg.type === "dangerDisplayed") {
    const extensionPage = sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html");
    if (sender.frameId !== 0 || (!extensionPage && sender.url !== msg.url)) return;
    return getState().then(async s => {
      if (!s.protect || !s.token) return false;
      const res = await fetch(RASID + "/api/demo/police-report", {
        method:"POST", headers:{"Content-Type":"application/json", Authorization:"Bearer "+s.token},
        body:JSON.stringify({url:msg.url})
      });
      const receipt = await res.json();
      return res.ok && receipt.recorded === true && receipt.simulated === true;
    });
  }
  if (msg.type === "prepare") {
    const destination = new URL(msg.url);
    if (sender.frameId !== 0 || !sender.url || destination.origin !== new URL(sender.url).origin ||
        !/^https?:$/.test(destination.protocol)) return;
    return getState().then(async s => {
      if (s.protect && s.token && !(safe.get(destination.href) > Date.now())) {
        await checkOnce(destination.href, s.token);
      }
      return true;
    });
  }
  if (msg.type === "check") {
    return getState().then(async s => {
      if (!s.protect || !s.token) return {inactive:true};
      const result = await checkOnce(String(msg.url || ""), s.token);
      const current = await getState();
      return current.protect && current.token === s.token ? result : {inactive:true};
    });
  }
});

// ---- Tab watcher: catches every link the moment Safari starts opening it — even a site that does not
// exist (where no page loads, so the page script never runs). If Rasid says no, the tab is sent to the
// Rasid block screen inside the extension.
const recent = new Map();
async function watch(tabId, url) {
  if (!url || !/^https?:/i.test(url) || new URL(url).origin === RASID) return;

  const key = tabId + " " + url;
  if (recent.has(key) && Date.now() - recent.get(key) < 5000) return;

  const s = await getState();
  if (!s.token || !s.protect || await visitApplies(tabId,url,s.token)) return;
  if (safe.get(url) > Date.now()) return;
  const r = await checkOnce(url, s.token);
  if (r.allow) return;
  const current = await getState();
  if (!current.protect || current.token !== s.token || await visitApplies(tabId,url,current.token)) return;
  try {
    const tab = await browser.tabs.get(tabId);
    if (tab.pendingUrl ? tab.pendingUrl !== url : tab.url !== url) return; // the user already went somewhere else
  } catch (e) { return; }
  if (recent.get(key) > Date.now() - 5000) return;
  if (recent.size >= 200) recent.clear();
  recent.set(key, Date.now());
  if (r.level === "suspicious") warnings.set(tabId, url);
  else warnings.delete(tabId);
  const q = new URLSearchParams({ level: r.level || "", score:String(r.score ?? ""), u: url, ar: r.reason_ar || "", en: r.reason_en || "", s: r.summary_ar || "", se: r.summary_en || "", lang: current.lang });
  browser.tabs.update(tabId, { url: browser.runtime.getURL("blocked.html") + "?" + q.toString() }).catch(() => {});
}
if (browser.webNavigation && browser.webNavigation.onErrorOccurred) {
  browser.webNavigation.onErrorOccurred.addListener((d) => { if (d.frameId === 0 && !/abort|cancel/i.test(d.error || "")) watch(d.tabId, d.url); });
}

// External links can fail DNS before Safari creates a page for content.js.
browser.tabs.onUpdated.addListener((id, change, tab) => {
  const url = change.url || (change.status === "loading" && tab.url);
  if (url && /^https?:/i.test(url)) watch(id, url).catch(() => {});
});

browser.webNavigation.onBeforeNavigate.addListener(event => {
  if (event.frameId === 0) watch(event.tabId, event.url).catch(() => {});
});
