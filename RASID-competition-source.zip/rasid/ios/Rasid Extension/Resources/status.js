(async function () {
  const label=document.querySelector("[role=status]");
  let ar=navigator.language.startsWith("ar");
  try {
    const state=await browser.runtime.sendMessage({type:"status"});
    if(state.lang) ar=state.lang==="ar";
    label.textContent=state.active ? (ar?"حماية سفاري مفعّلة":"Safari protection is on") : (ar?"افتح راصّد وشغّل الحماية.":"Open RASID and turn on protection.");
  } catch {label.textContent=ar?"تعذّر الاتصال براصّد.":"Could not contact RASID.";}
  document.documentElement.dir=ar?"rtl":"ltr";
  document.documentElement.lang=ar?"ar":"en";
})();
