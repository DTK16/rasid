import SafariServices

final class SafariWebExtensionHandler: NSObject, NSExtensionRequestHandling {
    func beginRequest(with context: NSExtensionContext) {
        let item = context.inputItems.first as? NSExtensionItem
        let request = item?.userInfo?[SFExtensionMessageKey] as? [String: String]
        var state: [String: Any] = ["protect": false]
        if request?["type"] == "setLanguage", let lang = request?["lang"], ["ar","en"].contains(lang),
           var session = try? Session.load(), session.lang != lang {
            session.lang = lang
            try? session.save()
        }
        if request?["type"] == "state", let session = try? Session.load() {
            state = ["protect": session.protect, "lang": session.lang]
            if session.protect { state["token"] = session.token }
        }
        let reply = NSExtensionItem()
        reply.userInfo = [SFExtensionMessageKey: state]
        context.completeRequest(returningItems: [reply])
    }
}
