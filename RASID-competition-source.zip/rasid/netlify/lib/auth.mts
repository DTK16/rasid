// Accounts and sessions for Rasid.
// Users live in a private Netlify Blobs store; passwords are hashed with scrypt (random salt).
// Sessions are signed tokens (HMAC-SHA256 with RASID_SECRET), sent as "Authorization: Bearer <token>".

import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const TOKEN_DAYS = 30;

export type User = { email: string; name: string; salt: string; hash: string; created: string; role: "user" | "admin" };
export type Session = { email: string; name: string; role: "user" | "admin" | "guest"; exp: number };

function secret(): string {
  const s = (globalThis as any).Netlify?.env?.get?.("RASID_SECRET") || process.env.RASID_SECRET;
  if (!s || s.length < 16) throw new Error("RASID_SECRET is not configured");
  return s;
}

export function adminEmails(): string[] {
  const raw = (globalThis as any).Netlify?.env?.get?.("RASID_ADMIN_EMAILS") || process.env.RASID_ADMIN_EMAILS || "";
  return raw.split(",").map((x: string) => x.trim().toLowerCase()).filter(Boolean);
}

export function usersStore() { return getStore({ name: "rasid-users", consistency: "strong" }); }

const b64u = (b: Buffer | string) => Buffer.from(b).toString("base64url");

export function signToken(s: Session): string {
  const body = b64u(JSON.stringify(s));
  const mac = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
  return `${body}.${mac}`;
}

export function verifyToken(token: string | null | undefined): Session | null {
  if (!token || !token.includes(".")) return null;
  const [body, mac] = token.split(".");
  let expected: string;
  try { expected = crypto.createHmac("sha256", secret()).update(body).digest("base64url"); } catch { return null; }
  const a = Buffer.from(mac || ""), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const s = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as Session;
    if ((!s.email && s.role !== "guest") || !s.exp || s.exp < Date.now()) return null;
    // During the closed-registration pilot, all password accounts can review threats.
    if (s.role === "guest") return s;
    if (!validEmail(s.email) || (s.role !== "user" && s.role !== "admin")) return null;
    return { ...s, role: "admin" };
  } catch { return null; }
}

export function sessionFrom(req: Request): Session | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return verifyToken(m ? m[1].trim() : null);
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex");
}

export function normEmail(e: string) { return String(e || "").trim().toLowerCase(); }
export function validEmail(e: string) { return /^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i.test(e); }

export async function createUser(email: string, name: string, password: string): Promise<{ ok: true; user: User } | { ok: false; code: string }> {
  email = normEmail(email);
  if (!validEmail(email)) return { ok: false, code: "bad_email" };
  if (String(password || "").length < 8) return { ok: false, code: "weak_password" };
  const salt = crypto.randomBytes(16).toString("hex");
  const user: User = {
    email, name: String(name || "").trim().slice(0, 60) || email.split("@")[0],
    salt, hash: hashPassword(password, salt), created: new Date().toISOString(),
    role: adminEmails().includes(email) ? "admin" : "user",
  };
  const res = await usersStore().setJSON("u/" + email, user, { onlyIfNew: true });
  if (!res.modified) return { ok: false, code: "exists" };
  return { ok: true, user };
}

export async function checkLogin(email: string, password: string): Promise<User | null> {
  email = normEmail(email);
  const u = (await usersStore().get("u/" + email, { type: "json" })) as User | null;
  if (!u) { hashPassword(String(password || ""), "x".repeat(32)); return null; } // even timing
  const h = hashPassword(String(password || ""), u.salt);
  const a = Buffer.from(h, "hex"), b = Buffer.from(u.hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return u;
}

export function sessionFor(u: User): { token: string; session: Session } {
  const session: Session = { email: u.email, name: u.name, role: "admin", exp: Date.now() + TOKEN_DAYS * 86400000 };
  return { token: signToken(session), session };
}

// CORS: the Safari extension and the Android app call the API from other origins.
export function cors(extra: Record<string, string> = {}): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Cache-Control": "no-store",
    ...extra,
  };
}

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: cors({ "Content-Type": "application/json; charset=utf-8" }) });
}
