import reportLogo from "./report-logo.json";
import {PDFDocument, StandardFonts, rgb, PageSizes} from "pdf-lib";

const color=(hex:string)=>rgb(...[0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)/255) as [number,number,number]);
const navy=color("132F46"), teal=color("187374"), ink=color("152C40"), muted=color("476174"), line=color("D8E4E7");
const white=rgb(1,1,1), tint=color("EDF5F4");
const printable=(s:unknown)=>String(s??"").replace(/[\u2010-\u2015]/g,"-").replace(/[^\x20-\x7e]/g," ").replace(/\s+/g," ").trim() || "Unavailable";

export async function incidentPDF(host:string, verdict:{level:string;score:number},reason:string,meta:any,jpeg:string,reference:string){
  const doc=await PDFDocument.create();
  const logo=await doc.embedPng(reportLogo);
  doc.setTitle("RASID incident report | "+host);doc.setAuthor("RASID");
  const regular=await doc.embedFont(StandardFonts.Helvetica), bold=await doc.embedFont(StandardFonts.HelveticaBold);
  const [W,H]=PageSizes.A4, margin=40, end=W-margin;
  const created=new Date().toISOString().replace("T"," ").slice(0,19)+" UTC";
  let page=doc.addPage([W,H]), y=0;
  function text(value:string,x:number,top:number,size:number,font=regular,shade=ink){
    page.drawText(value,{x,y:H-top-size,size,font,color:shade});
  }
  function rect(x:number,top:number,width:number,height:number,shade:ReturnType<typeof rgb>){
    page.drawRectangle({x,y:H-top-height,width,height,color:shade});
  }
  function header(title:string){
    rect(0,0,W,96,navy);rect(0,0,7,96,teal);
    rect(margin,12,72,72,white);
    page.drawImage(logo,{x:margin,y:H-84,width:72,height:72});
    text("RASID",margin+86,18,13,bold,white);text("INCIDENT RESPONSE",end-105,19,9,bold,color("B3D9D9"));
    text(title,margin+86,43,28,bold,white);y=116;
  }
  function ensure(space:number){if(y+space>H-54){page=doc.addPage([W,H]);header("Incident evidence");}}
  function wrap(value:unknown,width:number,size:number,font=regular){
    const rows:string[]=[];let row="";
    for(const word of printable(value).split(" ")){
      if(row && font.widthOfTextAtSize(row+" "+word,size)>width){rows.push(row);row="";}
      for(const ch of (row?" ":"")+word){
        if(row && font.widthOfTextAtSize(row+ch,size)>width){rows.push(row);row="";}row+=ch;
      }
    }
    rows.push(row);return rows;
  }
  function section(title:string){ensure(60);text(title,margin,y,15,bold,teal);y+=24;}
  function field(label:string,value:unknown){
    const rows=wrap(value,end-margin-151,10.5);
    ensure(24);text(label,margin,y,10,bold,muted);
    for(const row of rows){ensure(16);text(row,margin+143,y,10.5);y+=15;}
    y+=4;rect(margin,y,end-margin,.6,line);y+=6;
  }
  header("Incident report");
  text("REPORTED HOST",margin,y,9,bold,muted);y+=15;
  for(const row of wrap(host,end-margin,19,bold)){text(row,margin,y,19,bold);y+=23;}
  y+=10;rect(margin,y,end-margin,57,tint);
  const risk=verdict.level==="dangerous"?color("A63534"):color("8A590B");
  rect(margin,y,4,57,risk);text("CLASSIFICATION",margin+15,y+8,8,bold,muted);
  text(verdict.level==="dangerous"?"Dangerous":"Suspicious",margin+15,y+23,17,bold,risk);
  text("RISK SCORE",margin+190,y+8,8,bold,muted);
  text(verdict.score+" / 100",margin+190,y+23,17,bold);
  rect(margin+302,y+32,169,5,line);rect(margin+302,y+32,169*Math.max(0,Math.min(100,verdict.score))/100,5,risk);
  y+=74;section("Why RASID flagged this link");
  for(const row of wrap(reason,end-margin,11.5)){ensure(18);text(row,margin,y,11.5);y+=17;}
  y+=14;section("Domain registration");field("Registered domain",meta.registration?.domain);
  field("Registrar",meta.registration?.registrar);
  for(const [event,date] of meta.registration?.events||[])field(printable(event),date);
  field("Name servers",meta.registration?.nameservers?.join(", "));
  y+=13;section("Hosting and network");field("Resolved IP addresses",meta.addresses?.join(", "));
  field("IP used for estimate",meta.ip);field("Operator / ISP",[meta.network?.operator,meta.network?.isp].filter(Boolean).join(" / "));field("ASN",meta.network?.asn);
  field("Server or CDN location",[meta.network?.city,meta.network?.region,meta.network?.country].filter(Boolean).join(", "));field("Lookup time (UTC)",meta.observedUTC);
  if(Number.isFinite(meta.network?.latitude) && Number.isFinite(meta.network?.longitude)){
    field("Approximate coordinates",meta.network.latitude+", "+meta.network.longitude);
    field("Map estimate","IP-based hosting or CDN location. Open the online report for the interactive map.");
  }
  page=doc.addPage([W,H]);header("Warning screen");
  text("Captured on the reporting device",margin,y,12,bold);y+=27;
  const image=await doc.embedJpg(Uint8Array.from(Buffer.from(jpeg.slice(jpeg.indexOf(",")+1),"base64")));
  const dims=image.scaleToFit(end-margin-24,386);rect(margin,y,end-margin,dims.height+24,tint);
  page.drawImage(image,{x:(W-dims.width)/2,y:H-y-12-dims.height,...dims});y+=dims.height+45;
  section("Report details");field("Report created",created);field("Reference",reference);
  for(const source of meta.sources||[])field("Lookup source",source);
  for(const [i,p] of doc.getPages().entries()){page=p;rect(margin,H-38,end-margin,.7,line);text("RASID   /   "+reference,margin,H-29,8,bold,muted);text((i+1)+" / "+doc.getPageCount(),end-26,H-29,8,regular,muted);}
  return doc.save();
}
