import net from "node:net";

const MULTI_PART_SUFFIXES = new Set(["gov.ae", "co.ae", "net.ae", "org.ae", "ac.ae", "sch.ae", "mil.ae", "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.in", "com.sa", "gov.sa", "com.eg", "com.br", "co.jp", "com.tr", "com.bh", "gov.bh", "com.kw", "com.qa", "gov.qa", "com.om", "co.za", "com.cn", "com.mx", "com.sg", "com.my", "co.nz", "github.io", "netlify.app", "vercel.app", "pages.dev", "web.app", "firebaseapp.com", "blogspot.com", "herokuapp.com", "azurewebsites.net", "workers.dev", "glitch.me", "wixsite.com", "weebly.com", "000webhostapp.com", "r2.dev", "ngrok.io", "ngrok-free.app", "duckdns.org"]);

export function registrableDomain(host: string): string {
  if (net.isIP(host)) return host;
  const labels = host.split(".").filter(Boolean);
  if (labels.length <= 2) return labels.join(".");
  const lastTwo = labels.slice(-2).join(".");
  const lastThree = labels.slice(-3).join(".");
  if (MULTI_PART_SUFFIXES.has(lastTwo)) return labels.slice(-3).join(".");
  if (MULTI_PART_SUFFIXES.has(lastThree.split(".").slice(1).join("."))) return lastThree;
  return lastTwo;
}

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const p = ip.split(".").map(Number);
    const [a, b, c] = p;
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 192 && b === 0 && (c === 0 || c === 2)) return true;
    if (a === 192 && b === 88 && c === 99) return true;
    if (a === 198 && (b === 18 || b === 19)) return true;
    if (a === 198 && b === 51 && c === 100) return true;
    if (a === 203 && b === 0 && c === 113) return true;
    if (a >= 224) return true;
    return false;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === "::" || x === "::1") return true;
    if (x.startsWith("::ffff:")) { const v4 = x.slice(7); return net.isIPv4(v4) ? isPrivateIp(v4) : true; }
    if (/^f[cd]/.test(x) || /^fe[89ab]/.test(x) || /^ff/.test(x)) return true;
    if (x.startsWith("2001:db8") || x.startsWith("64:ff9b") || x.startsWith("2002:") || x.startsWith("100:")) return true;
    return false;
  }
  return true;
}
