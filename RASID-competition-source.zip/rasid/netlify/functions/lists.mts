// GET  /api/lists                 → Rasid's "caught" and "not yet caught" lists (signed-in users)
// POST /api/admin/review { host, status: "caught" | "not_caught" | "safe" }   (admins only)
import type { Config } from "@netlify/functions";
import { sessionFrom, json, cors } from "../lib/auth.mts";
import { listSites, reviewSite, sitesStore } from "../lib/sites.mts";
import { loadFeeds, isTrustedHost } from "../lib/engine.mts";

const defang = (s: string) => s.replace(/\./g, "[.]").replace(/^http/i, "hxxp");

export default async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  const s = sessionFrom(req);
  if (!s) return json({ error: "auth", error_en: "Please sign in first", error_ar: "سجّل الدخول أولاً" }, 401);
  const path = new URL(req.url).pathname;

  if (path.endsWith("/review")) {
    if (s.role !== "admin") return json({ error: "forbidden", error_en: "Only Rasid administrators can review sites", error_ar: "مراجعة المواقع لمسؤولي راصد فقط" }, 403);
    const b: any = await req.json().catch(() => ({}));
    const status = String(b.status || "");
    if (!["caught", "not_caught", "safe"].includes(status)) return json({ error: "bad_status" }, 400);
    const rec = await reviewSite(String(b.host || ""), status as any, s.email);
    if (!rec) return json({ error: "not_found" }, 404);
    return json({ ok: true, record: { ...rec, host: defang(rec.host), example: defang(rec.example) } });
  }

  const [sites, feeds] = await Promise.all([listSites(400), loadFeeds().catch(() => null)]);
  const view = (r: Awaited<ReturnType<typeof listSites>>[number]) => {
    if (s.role === "admin") return { ...r, host: defang(r.host), host_raw: r.host, example: defang(r.example) };
    return { host: defang(r.host), status: r.status, level: r.level, source: r.source,
      last_seen: r.last_seen, hits: r.hits,
      reason_ar: r.source === "admin" ? "راجعه مسؤول راصّد" : r.source === "threat_list" ? "تطابق مع قائمة تهديدات" : "رصدته فحوص راصّد",
      reason_en: r.source === "admin" ? "Reviewed by a RASID admin" : r.source === "threat_list" ? "Matched a threat list" : "Flagged by RASID checks" };
  };
  return json({
    demo_reports: s.role === "admin" ? (await sitesStore().list({prefix:"demo-police/"})).blobs.map(b => defang(b.key.slice("demo-police/".length))) : undefined,
    role: s.role,
    caught: sites.filter((r) => r.status === "caught").map(view),
    not_caught: sites.filter((r) => r.status === "not_caught" && !isTrustedHost(r.host)).map(view),
    cleared: s.role === "admin" ? sites.filter((r) => r.status === "safe").map(view) : [],
    public_lists: feeds ? feeds.states.map((f) => ({ name: f.name, status: f.status, entries: f.entries })) : [],
  });
};

export const config: Config = { path: ["/api/lists", "/api/admin/review"], method: ["GET", "POST", "OPTIONS"] };
