import reportLogo from "../lib/report-logo.json";
import type {Config} from "@netlify/functions";
import nodemailer from "nodemailer";
import {createHmac} from "node:crypto";
import {incidentPDF} from "../lib/incident-pdf.mts";
import {sessionFrom,json,cors} from "../lib/auth.mts";
import {sitesStore} from "../lib/sites.mts";
import {runCheck} from "../lib/engine.mts";
import evidenceHost from "./evidence.mts";

const env=(name:string)=> (globalThis as any).Netlify?.env?.get(name) || process.env[name];
const maxJPEG=700_000;
const base="https://rasid-link-checker.netlify.app/api/demo/report-link";
export default async function reportMail(req:Request) {
  if(req.method==="OPTIONS") return new Response(null,{status:204,headers:cors()});
  const url=new URL(req.url);
  if(req.method==="GET"){
    const id=url.searchParams.get("id") || "";
    const expiry=Number(url.searchParams.get("until"));
    if(!/^[a-f0-9]{64}$/.test(id) || !Number.isSafeInteger(expiry) || Date.now()>expiry) return new Response("Report unavailable",{status:404});
    if(createHmac("sha256",env("RASID_SECRET")).update(id+"."+expiry).digest("hex")!==url.searchParams.get("key")) return new Response("Report unavailable",{status:404});
    const stored=await sitesStore().getWithMetadata("mail-pdf/"+id,{type:"arrayBuffer"});
    const pdf=stored?.data;
    if (!pdf) return new Response("Report unavailable",{status:404});
    const headers={"Cache-Control":"no-store","Referrer-Policy":"no-referrer","X-Content-Type-Options":"nosniff","X-Robots-Tag":"noindex, nofollow"};
    const view=url.searchParams.get("view");
    if(view==="location") return Response.json(stored?.metadata?.serverLocation ?? {},{headers});
    if(view==="pdf" || view==="download") return new Response(pdf,{headers:{...headers,"Content-Type":"application/pdf","Content-Disposition":(view==="pdf"?"inline":"attachment")+'; filename="RASID-incident-report.pdf"'}});
    const query=new URLSearchParams({id,until:String(expiry),key:url.searchParams.get("key")!}).toString().replaceAll("&","&amp;");
    return new Response(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RASID | Report preview</title>
<style>*{box-sizing:border-box}body{margin:0;background:#edf2f3;color:#152c40;font:16px system-ui}header{background:#132f46;color:white}section,main{max-width:860px;margin:auto;padding:18px}section{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}h1{font-size:19px;margin:0;display:flex;align-items:center;gap:12px}h1 img{display:block;width:64px;height:64px;background:white;border-radius:8px}nav{display:flex;gap:14px}a{color:white;text-underline-offset:4px;font-size:14px}figure{margin:0 0 20px}canvas{width:100%;height:auto;display:block;background:white;box-shadow:0 2px 10px #132f4620}figcaption{text-align:center;font-size:12px;margin-top:6px}p{margin:0;padding:10px 0}</style>
<header><section><h1><img src="${reportLogo}" alt="RASID">Report preview</h1><nav><a href="?${query}&amp;view=pdf">Open PDF</a><a href="?${query}&amp;view=download">Download PDF</a></nav></section></header><main><host-location report expanded></host-location><p role="status">Loading report…</p><noscript>Choose Open PDF to view this report.</noscript></main><script src="/host-location.js"></script><script type="module" src="/report-preview.mjs"></script></html>`,{headers:{...headers,"Content-Type":"text/html; charset=utf-8","Content-Security-Policy":"default-src 'none'; script-src 'self'; worker-src 'self'; connect-src 'self'; style-src 'unsafe-inline'; font-src 'self' blob: data:; img-src 'self' data: blob:; frame-src https://www.openstreetmap.org; frame-ancestors 'none'; base-uri 'none'"}});

  }
  if(req.method!=="POST" || !sessionFrom(req)) return json({sent:false},401);
  const apiKey=env("RESEND_API_KEY"), from=env("RASID_REPORT_FROM"), to=env("RASID_REPORT_TO");
  const gmailPassword = env("RASID_GMAIL_APP_PASSWORD");
  if ((!gmailPassword && (!apiKey || !from)) || !to) return json({sent:false,error:"mail_unconfigured"},503);
  if(Number(req.headers.get("content-length"))>maxJPEG+9000) return json({sent:false},413);
  const body=await req.json().catch(()=>null);
  const jpeg=body?.screenshot;
  if(typeof jpeg!=="string" || jpeg.length>maxJPEG || !/^data:image\/jpeg;base64,\/9j\//.test(jpeg)) return json({sent:false,error:"screenshot"},400);
  let target:URL;
  try{target=new URL(body.url);if(!["http:","https:"].includes(target.protocol)||target.username||target.password)throw Error();}catch{return json({sent:false},400);}
  const day=new Date().toISOString().slice(0,10);
  const requestId=body.requestId;
  if(requestId !== undefined && (typeof requestId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestId))) {
    return json({sent:false,error:"invalid_request_id"},400);
  }
  // Older installed clients do not send a submission ID. Group their immediate retries.
  const submission=requestId ?? "legacy-"+Math.floor(Date.now()/60000);
  const id=createHmac("sha256",env("RASID_SECRET")).update(JSON.stringify([submission,target.href,"support.rasid@gmail.com",to])).digest("hex");
  const store=sitesStore();
  try {
    if(await store.get("mail-sent/"+id)) return json({sent:true,simulated:true});
    const result=await runCheck({input:target.href,mode:"gate"});
    if(!["dangerous","suspicious"].includes(result.body?.verdict?.level))return json({sent:false,error:"unconfirmed"},422);
    if(!await store.get("mail-pdf/"+id,{type:"arrayBuffer"})){
      const lookup=await evidenceHost(new Request(base+"?host="+encodeURIComponent(target.hostname)));
      const meta=lookup.ok ? await lookup.json() : {};
      const bytes=await incidentPDF(target.hostname,result.body.verdict,result.body.gate?.reason_en,meta,jpeg,id.slice(0,12).toUpperCase());
      await store.set("mail-pdf/"+id,Buffer.from(bytes),{onlyIfNew:true,metadata:{serverLocation:{host:target.hostname,ip:meta.ip || null,network:meta.network || null,observedUTC:meta.observedUTC || null}}});
    }
    const expiry=Date.parse(day+"T00:00:00Z")+7*86400000;
    const key=createHmac("sha256",env("RASID_SECRET")).update(id+"."+expiry).digest("hex");
    const link=base+"?"+new URLSearchParams({id,until:String(expiry),key});
    const recipients=[...new Set(["support.rasid@gmail.com",to.trim().toLowerCase()])];
    const label="بلاغ راصد - rasid report";
    const message = {to:recipients,subject:label,text:label,
      html:'<p><a href="'+link.replaceAll("&","&amp;")+'">'+label+'</a></p>'};
    if (gmailPassword) {
      const sender = "support.rasid@gmail.com";
      for (const [index, recipient] of recipients.entries()) {
        const delivery = id+"-"+index;
        const lock = "gmail-submitting/"+delivery;
        const sentKey = "gmail-accepted/"+delivery;
        if (await store.get(sentKey)) continue;
        const claim = await store.set(lock, "pending", {onlyIfNew:true});
        if (!claim.modified) return json({sent:false,error:"submission_pending"},409);
        try {
          const smtp = nodemailer.createTransport({host:"smtp.gmail.com",port:465,secure:true,
            auth:{user:sender,pass:gmailPassword.replace(/\s/g,"")},connectionTimeout:7000,socketTimeout:15000});
          const receipt = await smtp.sendMail({...message,to:recipient,from:sender,messageId:"<"+delivery+"@rasid-link-checker.netlify.app>"});
          if (!receipt.accepted.length) {
            await store.delete(lock);
            return json({sent:false,error:"mail_rejected"},502);
          }
          await store.set(sentKey,receipt.messageId);
        } catch(error) {
          // Explicit SMTP refusals and pre-DATA errors are safe to retry.
          // After an ambiguous DATA timeout keep the claim to prevent duplicate mail.
          const failure=error as {responseCode?:number;command?:string};
          if ((failure.responseCode || 0)>=400 || ["CONN","AUTH","AUTH PLAIN","AUTH LOGIN","MAIL FROM","RCPT TO"].includes(failure.command || "")) await store.delete(lock);
          return json({sent:false,error:"mail_unconfirmed"},502);
        }
      }
      await store.set("mail-sent/"+id,"accepted");
    } else {
      const accepted=await fetch("https://api.resend.com/emails",{method:"POST",signal:AbortSignal.timeout(10000),headers:{Authorization:"Bearer "+apiKey,"Content-Type":"application/json","Idempotency-Key":"rasid/"+id},body:JSON.stringify({...message,from})});
      const receipt=await accepted.json();
      if(!accepted.ok || !receipt.id)return json({sent:false,error:"mail_failed"},502);
      await store.set("mail-sent/"+id,String(receipt.id));
    }
    return json({sent:true,simulated:true});
  }catch{return json({sent:false,error:"report_failed"},502);}
}
export const config:Config={path:"/api/demo/report-link",method:["POST","GET","OPTIONS"],rateLimit:{windowLimit:10,windowSize:60,aggregateBy:["ip","domain"]}};
