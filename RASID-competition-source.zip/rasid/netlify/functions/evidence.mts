import type { Config } from "@netlify/functions";
import { isIP } from "node:net";
import { registrableDomain, isPrivateIp } from "../lib/domains.mts";


async function lookup(url: string) {
  try {
    const response = await fetch(url, {signal: AbortSignal.timeout(4500), headers: {Accept: "application/json, application/rdap+json"}});
    return response.ok ? await response.json() : null;
  } catch { return null; }
}
export default async (request: Request) => {
  const host = new URL(request.url).searchParams.get("host")?.toLowerCase() || "";
  const reply = (body: unknown, status = 200) => Response.json(body, {status, headers: {"Access-Control-Allow-Origin":"*", "Cache-Control":"no-store"}});
  if (host.length > 253 || (!isIP(host) && !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(host)) || (isIP(host) && isPrivateIp(host)))
    return reply({error:"Invalid public host"},400);
  const domain = registrableDomain(host);
  const registry = domain.endsWith(".com") ? "https://rdap.verisign.com/com/v1" : domain.endsWith(".net") ? "https://rdap.verisign.com/net/v1" : "https://rdap.org";
  const rdapURL = registry + "/domain/" + encodeURIComponent(domain);
  const dnsURL = "https://dns.google/resolve?name=" + encodeURIComponent(host);
  const [rdap, a, aaaa] = await Promise.all([isIP(host) ? null : lookup(rdapURL), isIP(host) ? null : lookup(dnsURL+"&type=A"), isIP(host) ? null : lookup(dnsURL+"&type=AAAA")]);
  const addresses: string[] = isIP(host) ? [host] : [...(a?.Answer || []), ...(aaaa?.Answer || [])].map(r=>String(r.data)).filter(ip=>isIP(ip) && !isPrivateIp(ip));
  const ip = addresses[0];
  const geoURL = ip && "https://ipwho.is/"+encodeURIComponent(ip);
  const geo = geoURL && await lookup(geoURL);
  const registrar = rdap?.entities?.find((e:any)=>e.roles?.includes("registrar"));
  return reply({host, observedUTC:new Date().toISOString(), registration:rdap ? {domain:rdap.ldhName, registrar:registrar?.vcardArray?.[1]?.find((v:any)=>v[0]==="fn")?.[3],events:rdap.events?.map((e:any)=>[e.eventAction,e.eventDate]),nameservers:rdap.nameservers?.map((n:any)=>n.ldhName)} : null,
    addresses, ip, network:geo?.success ? {operator:geo.connection?.org,isp:geo.connection?.isp,asn:geo.connection?.asn,latitude:Number.isFinite(geo.latitude) && Math.abs(geo.latitude)<=90 ? geo.latitude : null,longitude:Number.isFinite(geo.longitude) && Math.abs(geo.longitude)<=180 ? geo.longitude : null,city:geo.city,region:geo.region,country:geo.country} : null,
    sources:[!isIP(host) && rdapURL,!isIP(host) && dnsURL,geoURL].filter(Boolean)});
};
export const config: Config = {path:"/api/evidence-host", method:["GET"], rateLimit:{windowLimit:20, windowSize:60, aggregateBy:["ip","domain"]}};
