// Rasid's own records of suspicious sites ("caught" / "not yet caught") and a short-lived verdict cache.

import { getStore } from "@netlify/blobs";

export type SiteStatus = "caught" | "not_caught" | "safe";
export type SiteRecord = {
  host: string;
  example: string;          // redacted example URL
  level: "suspicious" | "dangerous" | "safe";
  score: number;
  status: SiteStatus;
  source: "threat_list" | "rasid" | "admin";
  reason_en: string;
  reason_ar: string;
  first_seen: string;
  last_seen: string;
  hits: number;
  reviewed_by?: string;
  reviewed_at?: string;
};

export function sitesStore() { return getStore({ name: "rasid-sites", consistency: "strong" }); }
export function cacheStore() { return getStore({ name: "rasid-verdict-cache" }); }

const key = (host: string) => "h/" + host.toLowerCase().replace(/^www\./, "");

export async function getSite(host: string): Promise<SiteRecord | null> {
  try { return (await sitesStore().get(key(host), { type: "json" })) as SiteRecord | null; } catch { return null; }
}

// Record a suspicious or dangerous result. A human review (admin) always wins over automatic updates.
export async function recordSite(input: Omit<SiteRecord, "first_seen" | "last_seen" | "hits" | "status"> & { confirmed: boolean }): Promise<void> {
  const now = new Date().toISOString();
  const store = sitesStore();
  const prev = await getSite(input.host);
  let status: SiteStatus = input.confirmed ? "caught" : "not_caught";
  if (prev?.source === "admin") status = prev.status; // reviewed by a person: keep their decision
  else if (prev?.status === "caught") status = "caught";
  const rec: SiteRecord = {
    host: input.host, example: input.example, level: input.level, score: input.score,
    status, source: prev?.source === "admin" ? "admin" : input.source,
    reason_en: input.reason_en, reason_ar: input.reason_ar,
    first_seen: prev?.first_seen || now, last_seen: now, hits: (prev?.hits || 0) + 1,
    reviewed_by: prev?.reviewed_by, reviewed_at: prev?.reviewed_at,
  };
  await store.setJSON(key(input.host), rec);
}

export async function reviewSite(host: string, status: SiteStatus, by: string): Promise<SiteRecord | null> {
  const prev = await getSite(host);
  if (!prev) return null;
  const rec: SiteRecord = { ...prev, status, source: "admin", reviewed_by: by, reviewed_at: new Date().toISOString() };
  await sitesStore().setJSON(key(host), rec);
  return rec;
}

export async function listSites(limit = 300): Promise<SiteRecord[]> {
  const store = sitesStore();
  const { blobs } = await store.list({ prefix: "h/" });
  const recs = await Promise.all(blobs.slice(0, 1000).map((b) => store.get(b.key, { type: "json" }).catch(() => null)));
  return (recs.filter(Boolean) as SiteRecord[]).sort((a, b) => b.last_seen.localeCompare(a.last_seen)).slice(0, limit);
}

// Verdict cache: keeps automatic (gate) checks fast and cheap. Entries expire after `ttlMs`.
export async function getCached(k: string): Promise<any | null> {
  try {
    const e = await cacheStore().getWithMetadata(k, { type: "json" });
    if (e === null) return null;
    const exp = Number((e.metadata as any)?.exp || 0);
    if (exp && exp < Date.now()) return null;
    return e.data;
  } catch { return null; }
}

export async function setCached(k: string, value: unknown, ttlMs: number): Promise<void> {
  try { await cacheStore().setJSON(k, value, { metadata: { exp: Date.now() + ttlMs } }); } catch {}
}
