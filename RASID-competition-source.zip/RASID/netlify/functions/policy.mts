// GET /api/policy → latest phone versions required by Rasid, and official report channels. Public.
import type { Config } from "@netlify/functions";
import { json, cors } from "../lib/auth.mts";
import { REPORT_CHANNELS, BANK_CHANNELS } from "../lib/engine.mts";

export default async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  const env = (k: string, d: string) => (globalThis as any).Netlify?.env?.get?.(k) || process.env[k] || d;
  return json({
    // Update these when Apple / Google ship a new version (or set them as Netlify environment variables).
    latest: { ios: env("LATEST_IOS", "15.0"), android: env("LATEST_ANDROID", "17") },
    report_channels: REPORT_CHANNELS,
    banks: BANK_CHANNELS,
  });
};

export const config: Config = { path: "/api/policy", method: ["GET", "OPTIONS"] };
