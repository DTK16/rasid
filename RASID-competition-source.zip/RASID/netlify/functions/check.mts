// POST /api/check  { "url": "...", "mode": "scan" | "gate" }   or   { "sample": "feed" }
// Requires a signed-in Rasid account.
import type { Config } from "@netlify/functions";
import { sitesStore } from "../lib/sites.mts";
import { runCheck } from "../lib/engine.mts";
import { sessionFrom, json, cors } from "../lib/auth.mts";

export default async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  const session = sessionFrom(req);
  if (!session) return json({ error: "auth", error_en: "Please sign in to Rasid first", error_ar: "سجّل الدخول إلى راصد أولاً" }, 401);

  const report = new URL(req.url).pathname === "/api/demo/police-report";
  if (report && req.method !== "POST") return json({error:"method"},405);
  let input = "", sample = false, mode: "scan" | "gate" = "scan";
  if (req.method === "GET") {
    const q = new URL(req.url).searchParams;
    input = q.get("url") || ""; sample = q.get("sample") === "feed"; mode = q.get("mode") === "gate" ? "gate" : "scan";
  } else {
    const b: any = await req.json().catch(() => ({}));
    input = String(b?.url || ""); sample = b?.sample === "feed"; mode = b?.mode === "gate" ? "gate" : "scan";
  }
  try {
    const r = await runCheck({ input, sample: report ? false : sample, mode: report ? "gate" : mode, user: session.role === "guest" ? "guest" : session.email });
    if (report) {
      if (r.status !== 200 || r.body.verdict?.level !== "dangerous") return json({recorded:false}, 422);
      const host = new URL(input).hostname;
      await sitesStore().setJSON("demo-police/" + host, {host, created:new Date().toISOString()}, {onlyIfNew:true});
      return json({recorded:true, simulated:true});
    }
    return json(r.body, r.status);
  } catch (e: any) {
    // Fail-safe: an internal error never lets a link through.
    return json({ error_en: "Rasid could not complete the check, so the link stays blocked", error_ar: "تعذّر على راصد إكمال الفحص، لذلك يبقى الرابط ممنوعاً", gate: { allow: false, unsure: true, reason_en: "Check failed — blocked as a precaution", reason_ar: "فشل الفحص — تم المنع احتياطاً" }, detail: String(e?.message || e).slice(0, 200) }, 500);
  }
};

export const config: Config = {
  path: ["/api/check", "/api/demo/police-report"],
  method: ["GET", "POST", "OPTIONS"],
  rateLimit: { windowLimit: 40, windowSize: 60, aggregateBy: ["ip", "domain"] },
};
