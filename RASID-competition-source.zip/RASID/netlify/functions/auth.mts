// /api/auth/signup  { email, name, password }
// /api/auth/login   { email, password }
// /api/auth/me      (Authorization: Bearer <token>)
import type { Config, Context } from "@netlify/functions";
import { createUser, checkLogin, sessionFor, signToken, sessionFrom, json, cors } from "../lib/auth.mts";

const ERR: Record<string, [string, string, number]> = {
  bad_email: ["Enter a valid email address", "أدخل بريداً إلكترونياً صحيحاً", 400],
  weak_password: ["Password must be at least 8 characters", "كلمة المرور يجب أن تكون 8 أحرف على الأقل", 400],
  exists: ["An account with this email already exists. Sign in instead", "يوجد حساب بهذا البريد، سجّل الدخول بدلاً من ذلك", 409],
  bad_login: ["Wrong email or password", "البريد أو كلمة المرور غير صحيحة", 401],
};
const fail = (code: string) => json({ error: code, error_en: ERR[code][0], error_ar: ERR[code][1] }, ERR[code][2]);

export default async (req: Request, context: Context) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  const action = new URL(req.url).pathname.split("/").pop();
  try {
    if (action === "me") {
      const s = sessionFrom(req);
      if (!s) return json({ error: "auth" }, 401);
      return json({ user: { email: s.email, name: s.name, role: s.role } });
    }
    if (req.method !== "POST") return json({ error: "method" }, 405);
    if (action === "guest" || action === "demo-pass") {
      const user = { email: "", name: action === "demo-pass" ? "Demo Resident" : "Guest", role: "guest" as const };
      const token = signToken({ ...user, exp: Date.now() + 86400000 });
      return json({ token, user });
    }
    const b: any = await req.json().catch(() => ({}));
    if (action === "signup") {
      const r = await createUser(b.email, b.name, b.password);
      if (!r.ok) return fail(r.code);
      const { token, session } = sessionFor(r.user);
      return json({ token, user: { email: session.email, name: session.name, role: session.role } });
    }
    if (action === "login") {
      const u = await checkLogin(b.email, b.password);
      if (!u) return fail("bad_login");
      const { token, session } = sessionFor(u);
      return json({ token, user: { email: session.email, name: session.name, role: session.role } });
    }
    return json({ error: "not_found" }, 404);
  } catch (e: any) {
    return json({ error: "server", error_en: "Something went wrong. Please try again", error_ar: "حدث خطأ، حاول مرة أخرى", detail: String(e?.message || e).slice(0, 160) }, 500);
  }
};

export const config: Config = {
  path: ["/api/auth/demo-pass", "/api/auth/guest", "/api/auth/signup", "/api/auth/login", "/api/auth/me"],
  method: ["GET", "POST", "OPTIONS"],
  rateLimit: { windowLimit: 20, windowSize: 60, aggregateBy: ["ip", "domain"] },
};
