import Combine
import SafariServices
import SwiftUI
import WebKit

private let site = URL(string: "https://rasid-link-checker.netlify.app/")!
private let extensionID = "ae.rasid.Rasid.Extension"

struct RasidOnboardingView: View {
    @AppStorage("rasid_lang") private var language = Locale.preferredLanguages.first?.hasPrefix("ar") == true ? "ar" : "en"
    @AppStorage("rasid_appearance") private var appearance = 0
    @Environment(\.scenePhase) private var phase
    @State private var session = try? Session.load()
    @State private var sessionError = false
    @StateObject private var navigation = CheckerNavigation()
    @State private var setup = false
    @State private var enabled: Bool?
    @State private var settingsError = false
    private var arabic: Bool { language == "ar" }
    private func t(_ ar: String, _ en: String) -> String { arabic ? ar : en }

    var body: some View {
        Group {
            if let current = session {
                ZStack {
                    CheckerView(session: current, onUpdate: update, onSignOut: signOut, navigation: navigation)
                        .ignoresSafeArea(.container, edges: [.top, .bottom])
                        .id(current.token + (current.protect ? ":on" : ":off"))
                        .opacity(setup ? 0 : 1)
                        .allowsHitTesting(!setup)
                        .accessibilityHidden(setup)
                    if setup {
                        NavigationView {
                            List {
                                Section {
                                    Picker(t("اللغة", "Language"), selection: $language) {
                                        Text(verbatim: "English").tag("en")
                                        Text(verbatim: "العربية").tag("ar")
                                    }.pickerStyle(.segmented)
                                }
                                Section(t("المظهر", "Appearance")) {
                                    Picker(t("المظهر", "Appearance"), selection: $appearance) {
                                        Text(t("النظام", "System")).tag(0)
                                        Text(t("فاتح", "Light")).tag(1)
                                        Text(t("داكن", "Dark")).tag(2)
                                    }.pickerStyle(.segmented)
                                }
                                Section(t("حماية سفاري", "Safari protection")) {
                                    Toggle(t("راصّد في سفاري", "Check links in Safari"), isOn: Binding(
                                        get: { session?.protect == true },
                                        set: { update($0, language) }))
                                    Text(enabled.map { $0 ? t("الإضافة مفعّلة", "Extension enabled") : t("الإضافة غير مفعّلة", "Extension off") } ?? t("تحقق من إعدادات سفاري", "Check Safari Settings"))
                                    Text(t("فعّل راصد واسمح له بالوصول إلى المواقع التي تبا تفحصها.", "Enable Rasid and allow access to the websites you want it to check."))
                                    Button(t("إعدادات الإضافة", "Open extension settings")) {
                                        if #available(iOS 26.2, *) {
                                            SFSafariSettings.openExtensionsSettings(forIdentifiers: [extensionID]) { error in
                                                settingsError = error != nil
                                            }
                                        } else { settingsError = true }
                                    }
                                }
                                Section(t("حساب راصد", "Rasid account")) {
                                    OpenPassButton(arabic: arabic)
                                    Text(current.user.role == "guest" ? t("ضيف", "Guest") : current.user.email)
                                    Button(current.user.role == "guest" ? t("إنهاء جلسة الضيف", "Leave guest mode") : t("تسجيل الخروج", "Sign out"), role: .destructive, action: signOut)
                                }
                            }
                            .navigationTitle(t("الإعدادات", "Settings"))
                        }.navigationViewStyle(.stack)
                    }
                }
                .safeAreaInset(edge: .bottom, spacing: 0) { bottomMenu }
            } else {
                SignInView(language: $language) { newSession in
                    try newSession.save()
                    session = newSession
                    setup = true
                }
            }
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .environment(\.locale, Locale(identifier: language))
        .onChange(of: language) { next in
            if let session { update(session.protect, next) }
        }
        .alert(t("تعذّر حفظ الجلسة", "Could not update the shared session"), isPresented: $sessionError) {
            Button(t("موافق","OK")) {}
        }
        .environment(\.layoutDirection, arabic ? .rightToLeft : .leftToRight)
        .task(id: phase) {
            guard phase == .active else { return }
            if #available(iOS 26.2, *) {
                enabled = try? await SFSafariExtensionManager.stateOfExtension(withIdentifier: extensionID).isEnabled
            }
        }
        .alert(t("إعدادات سفاري", "Safari Settings"), isPresented: $settingsError) {
            Button(t("موافق","OK")) {}
        } message: { Text(t("الإعدادات ← التطبيقات ← سفاري ← الإضافات ← راصد", "Settings → Apps → Safari → Extensions → Rasid")) }
    }
    private var bottomMenu: some View {
        SystemMenu(
            titles: [t("الحماية", "Protect"), t("القوائم", "Lists"), t("إبلاغ", "Report"),
                     t("حسابي", "Account"), t("الإعدادات", "Settings")],
            selected: setup ? "settings" : navigation.selected,
            rtl: arabic
        ) { tab in
            setup = tab == "settings"
            if !setup { navigation.select(tab) }
        }
        .frame(height: 60)
    }

    private func update(_ protect: Bool, _ lang: String) {
        guard var next = session else { return }
        next.protect = protect
        next.lang = lang
        do { try next.save(); session = next; language = lang }
        catch { sessionError = true }
    }
    private func signOut() {
        do { try Session.clear(); session = nil; setup = false; navigation.selected = "home" }
        catch { sessionError = true }
    }

}

private struct SystemMenu: UIViewRepresentable {
    private static let tabs = ["home", "lists", "report", "account", "settings"]
    private static let icons = ["shield", "list.bullet", "flag", "person", "gearshape"]
    let titles: [String]
    let selected: String
    let rtl: Bool
    let select: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITabBar {
        let bar = UITabBar()
        bar.itemPositioning = .fill
        bar.items = Self.tabs.indices.map {
            UITabBarItem(title: titles[$0], image: UIImage(systemName: Self.icons[$0]), tag: $0)
        }
        bar.delegate = context.coordinator
        let slide = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.slide(_:)))
        slide.delegate = context.coordinator
        bar.addGestureRecognizer(slide)
        return bar
    }
    func updateUIView(_ bar: UITabBar, context: Context) {
        context.coordinator.owner = self
        bar.semanticContentAttribute = rtl ? .forceRightToLeft : .forceLeftToRight
        for item in bar.items ?? [] { item.title = titles[item.tag] }
        bar.selectedItem = bar.items?.first { Self.tabs[$0.tag] == selected }
    }
    final class Coordinator: NSObject, UITabBarDelegate, UIGestureRecognizerDelegate {
        var owner: SystemMenu
        init(_ owner: SystemMenu) { self.owner = owner }
        func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
            owner.select(SystemMenu.tabs[item.tag])
        }
        func gestureRecognizerShouldBegin(_ gesture: UIGestureRecognizer) -> Bool {
            guard let pan = gesture as? UIPanGestureRecognizer else { return true }
            let velocity = pan.velocity(in: pan.view)
            return abs(velocity.x) > abs(velocity.y)
        }
        @objc func slide(_ gesture: UIPanGestureRecognizer) {
            guard let bar = gesture.view as? UITabBar, let items = bar.items, !items.isEmpty,
                  bar.bounds.width > 0 else { return }
            switch gesture.state {
            case .began, .changed, .ended:
                let fraction = gesture.location(in: bar).x / bar.bounds.width
                let index = min(items.count - 1, max(0, Int(fraction * CGFloat(items.count))))
                let item = items[owner.rtl ? items.count - 1 - index : index]
                bar.selectedItem = item
                if gesture.state == .ended { tabBar(bar, didSelect: item) }
            case .cancelled, .failed:
                bar.selectedItem = items.first { SystemMenu.tabs[$0.tag] == owner.selected }
            default: break
            }
        }
    }
}

private final class CheckerNavigation: ObservableObject {
    @Published var selected = "home"
    weak var web: WKWebView?

    func select(_ tab: String) {
        guard ["home", "lists", "report", "account"].contains(tab) else { return }
        selected = tab
        web?.evaluateJavaScript("document.querySelector('#tabs [data-tab=\(tab)]')?.click()")
    }
}

private struct CheckerView: UIViewRepresentable {
    let session: Session
    let onUpdate: (Bool, String) -> Void
    let onSignOut: () -> Void
    let navigation: CheckerNavigation

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.add(context.coordinator, name: "rasidApp")
        let logo = UIImage(named: "LargeIcon")?.pngData()?.base64EncodedString() ?? ""
        let encoded = (try? JSONEncoder().encode(session))?.base64EncodedString() ?? ""
        let script = """
        if (location.origin === 'https://rasid-link-checker.netlify.app') {
          const bytes = Uint8Array.from(atob('\(encoded)'), c => c.charCodeAt(0));
          const initial = JSON.parse(new TextDecoder().decode(bytes));
          if (!localStorage.getItem('rasid_token')) {
            localStorage.setItem('rasid_token', initial.token);
            localStorage.setItem('rasid_user', JSON.stringify(initial.user));
            localStorage.setItem('rasid_lang', initial.lang);
            localStorage.setItem('rasid_protect', initial.protect ? '1' : '0');
          }
          document.addEventListener('click', event => {
            const lists = event.target.closest?.('button[data-tab="lists"]');
            if (lists && initial.user.role === 'guest') {
              event.preventDefault();
              event.stopImmediatePropagation();
              document.querySelectorAll('#tabs button').forEach(tab => tab.classList.toggle('on', tab === lists));
              const en = document.documentElement.lang === 'en';
              const t = (ar, english) => en ? english : ar;
              const main = document.getElementById('main');
              const node = (tag,text) => { const e = document.createElement(tag); e.textContent = text; return e; };
              function draw() {
                const card = document.createElement('section');
                card.className = 'card';
                card.append(node('h2',t('عرض لوحة المسؤول','Admin demo')),node('p',t('بيانات تجريبية للتدريب على مراجعة المواقع.','Sample records for demonstrating site reviews.')));
                const state = sessionStorage.getItem('demoReview') || 'pending';
                card.append(node('h3',t('مراجعة المواقع','Site review')),node('p','card-verification[.]example'));
                const labels = {pending:t('بانتظار المراجعة','Awaiting review'),caught:t('تم ضبطه','Confirmed fraud'),safe:t('آمن','Cleared')};
                card.append(node('p',labels[state]));
                for (const [next,title] of [['caught',t('تأكيد الاحتيال','Confirm fraud')],['safe',t('تعليم الموقع كآمن','Mark safe')],['pending',t('إعادة التجربة','Reset demo')]]) {
                  if (state === next) continue;
                  const action = node('button',title);
                  action.className = 'ghost';
                  action.onclick = () => {sessionStorage.setItem('demoReview',next);draw();};
                  card.append(action);
                }
                const report = document.createElement('section');
                report.className = 'card';
                report.append(node('h2',t('بلاغ تجريبي للشرطة','Simulated police report')),node('p','fake-checkout[.]example'),node('p',t('مثال لتحذير خطير. لا يُرسل إلى الشرطة.','Example of a dangerous warning. No report is sent to police.')));
                main.replaceChildren(card,report);
              }
              draw();
              window.scrollTo(0,0);
              return;
            }
            const button = event.target.closest?.('button.rasid-btn');
            if (!button || !event.isTrusted) return;
            event.preventDefault();
            event.stopImmediatePropagation();
            window.webkit.messageHandlers.rasidApp.postMessage({
              signedIn: true, requestedProtection: button.getAttribute('aria-pressed') !== 'true'
            });
          }, true);
          document.addEventListener('DOMContentLoaded', () => {
            const style = document.createElement('style');
            style.textContent = '#nl-badge-frame {position:static !important;display:block;margin-inline-start:auto !important} main.wrap {padding-bottom:16px} body {padding-bottom:calc(64px + env(safe-area-inset-bottom))}';
            style.textContent += ' header.top {padding-top:calc(14px + env(safe-area-inset-top))}';
            style.textContent += `
              #tabs {display:none!important}
              :root {color-scheme:light dark}
              html:lang(en) body {font-family:Inter,-apple-system,sans-serif}
              html:lang(ar) body {font-family:"IBM Plex Sans Arabic",-apple-system,sans-serif}
              h1,h2,h3,.brand .grow,.status {font-family:inherit;font-weight:700;line-height:1.35}
              h1 {font-size:1.65rem} h2 {font-size:1.22rem} .brand .grow {font-size:1.16rem}
              html:lang(en) :is(h1,h2,h3,.brand .grow) {letter-spacing:-.025em}
              button,input,textarea,.sub,.rasid-btn small {font-family:inherit}
              @media(prefers-color-scheme:dark) {
                :root {--bg:#101923;--card:#192735;--line:#364857;--ink:#edf3f7;--muted:#b9c8d1;--teal:#83d2d6;--grn-d:#96dfb6;--grn-t:#193e2c;--red-t:#49221f;--red-d:#ffb6ae;--amb-t:#46351b;--amb-d:#ffda92}
                nav.tabs,.ghost,input,textarea,input.search,.seg button.on,.rasid-btn:not(.on) {background:var(--card);color:var(--ink);border-color:var(--line)}
                .seg,.chip,.how div,.excerpt,.cite,.count,.step,.note,.warnbox {background:#223441;color:var(--ink);border-color:var(--line)}
                .primary {background:#146d75} .meta,[style*="color:#334155"] {color:var(--muted)!important}
                .rasid-btn:not(.on) {box-shadow:0 0 0 8px #233b45,0 0 0 10px var(--teal)}
              }`;
            document.head.append(style);
            const tabs = document.getElementById('tabs');
            if (tabs) {
              new MutationObserver(() => {
                const activeTab = tabs.querySelector('button.on')?.dataset.tab;
                if (activeTab) window.webkit.messageHandlers.rasidApp.postMessage({signedIn:true,activeTab});
              }).observe(tabs, {attributes:true, attributeFilter:['class'], subtree:true});
            }
            const english = document.documentElement.lang === 'en';
            const brand = document.querySelector('header .grow');
            if (brand) brand.textContent = '';
            const languageButtons = document.querySelectorAll('.langbar button');
            languageButtons.forEach(button => {
              button.textContent = button.dataset.lang === 'en'
                ? 'English' : 'العربية';
            });
            function localizeControls() {
              const button = document.querySelector('.rasid-btn');
              const input = document.querySelector('#q');
              if (input && !document.getElementById('check-guide')) {
                const card = document.createElement('section');
                card.id = 'check-guide';
                card.className = 'card';
                const heading = document.createElement('h2');
                heading.textContent = english ? 'How Rasid checks a link' : 'كيف يفحص راصد الرابط؟';
                const list = document.createElement('ol');
                list.style.cssText = 'padding-inline-start:1.4em;line-height:1.65';
                const steps = english ? [
                  'Check the address for lookalike names and misleading domains.',
                  'Compare it with known scam links and reviewed sites.',
                  'When reachable, inspect redirects and forms asking for sensitive details.',
                  'When available, AI weighs the findings and explains the risk.'
                ] : [
                  'يفحص العنوان بحثاً عن أسماء مقلّدة ونطاقات مضللة.',
                  'يقارنه بروابط الاحتيال المعروفة والمواقع التي روجعت.',
                  'إذا أمكن الوصول إلى الصفحة، يفحص التحويلات والنماذج التي تطلب بيانات حساسة.',
                  'عند توفره، يقيّم الذكاء الاصطناعي نتائج الفحص ويشرح سبب التصنيف.'
                ];
                for (const text of steps) {
                  const item = document.createElement('li');
                  item.textContent = text;
                  list.append(item);
                }
                const demo = document.createElement('button');
                demo.className = 'ghost';
                demo.textContent = english ? 'Try a fake bank alert' : 'جرّب مثال رسالة مصرفية مزيفة';
                demo.onclick = () => {
                  input.value = english
                    ? 'Your Emirates NBD card is frozen. Enter your one-time code at https://emiratesnbd-card-verify.example/otp'
                    : 'تم إيقاف بطاقتك في بنك الإمارات دبي الوطني. أدخل رمز التحقق عبر https://emiratesnbd-card-verify.example/otp';
                  input.closest('.card').querySelector('button.primary').click();
                  document.getElementById('out')?.scrollIntoView({block:'start'});
                };
                card.append(heading,list,demo);
                document.getElementById('out').after(card);
              }
              const label = button?.firstChild;
              if (label?.nodeType === 3 && label.data.trim() === 'ارصُد') label.data = english ? 'Protect' : 'راصّد';
              const nodes = document.createTreeWalker(document.querySelector('main') || document.body, NodeFilter.SHOW_TEXT);
              while (nodes.nextNode()) {
                const node = nodes.currentNode;
                const cleaned = node.data.replaceAll(' — ', ' · ').replaceAll('—', '…').replaceAll('ارصُد', english ? 'Protect' : 'راصّد');
                if (cleaned !== node.data) node.data = cleaned;
              }
              const who = document.querySelector('#who');
              if (!english && who?.textContent === 'Guest') who.textContent = 'ضيف';
              if (english) {
                const status = document.querySelector('.status .sub-en');
                if (status?.textContent.includes('ارصُد')) status.textContent = 'Tap Protect to turn protection on';
              }
            }
            new MutationObserver(localizeControls).observe(document.body, {childList:true,subtree:true,characterData:true});
            localizeControls();
            const shield = document.querySelector('header .brand > svg');
            if (shield) {
              const image = new Image(64,64);
              image.alt = 'راصّد Rasid';
              image.style.cssText = 'object-fit:contain;filter:drop-shadow(0 0 1px #c9d9dd)';
              image.src = 'data:image/png;base64,\(logo)';
              shield.replaceWith(image);
            }
          });
          let last;
          new MutationObserver(() => {
            const state = {signedIn: !!localStorage.getItem('rasid_token'),
              protect: localStorage.getItem('rasid_protect') === '1',
              lang: localStorage.getItem('rasid_lang') || 'ar'};
            const value = JSON.stringify(state);
            if (last !== value) { last = value; window.webkit.messageHandlers.rasidApp.postMessage(state); }
          }).observe(document, {childList:true,subtree:true});
        }
        """
        configuration.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        // The deployed device policy reads the Safari version from the user agent.
        configuration.applicationNameForUserAgent = "Version/" + UIDevice.current.systemVersion
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.scrollView.contentInsetAdjustmentBehavior = .never
        navigation.web = web
        web.navigationDelegate = context.coordinator
        web.load(URLRequest(url: site))
        return web
    }
    func updateUIView(_ web: WKWebView, context: Context) {
        let old = context.coordinator.owner.session
        context.coordinator.owner = self
        guard web.url?.host == site.host, old.lang != session.lang || old.protect != session.protect else { return }
        let js = """
        if (location.origin === 'https://rasid-link-checker.netlify.app' &&
            (localStorage.rasid_lang !== lang || localStorage.rasid_protect !== protect)) {
          localStorage.rasid_lang = lang; localStorage.rasid_protect = protect; location.reload();
        }
        """
        Task { _ = try? await web.callAsyncJavaScript(js, arguments: ["lang": session.lang, "protect": session.protect ? "1" : "0"], in: nil, contentWorld: .page) }
    }
    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var owner: CheckerView
        init(_ owner: CheckerView) { self.owner = owner }
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            let origin = message.frameInfo.securityOrigin
            guard message.frameInfo.isMainFrame, origin.protocol == "https", origin.host == site.host,
                  let body = message.body as? [String: Any], let signedIn = body["signedIn"] as? Bool else { return }
            if let tab = body["activeTab"] as? String,
               ["home", "lists", "report", "account"].contains(tab) {
                if owner.navigation.selected != tab { owner.navigation.selected = tab }
                return
            }
            if let requested = body["requestedProtection"] as? Bool {
                owner.onUpdate(requested, owner.session.lang)
                return
            }
            if !signedIn { owner.onSignOut(); return }
            // The native settings switch owns protection state. The web view can
            // briefly report stale localStorage while it reloads after a change.
            if let lang = body["lang"] as? String,
               ["ar", "en"].contains(lang), lang != owner.session.lang {
                owner.onUpdate(owner.session.protect, lang)
            }
        }
        func webView(_ web: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard action.targetFrame?.isMainFrame != false, let url = action.request.url else {
                decisionHandler(.allow); return
            }
            if url.scheme == "https", url.host == site.host { decisionHandler(.allow); return }
            decisionHandler(.cancel)
            if action.navigationType == .linkActivated, ["https","tel","mailto","sms"].contains(url.scheme ?? "") {
                UIApplication.shared.open(url)
            }
        }
        func webView(_ web: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            guard (error as NSError).code != NSURLErrorCancelled, web.viewWithTag(901) == nil else { return }
            let retry = UIButton(type: .system)
            retry.tag = 901
            retry.setTitle(owner.session.lang == "ar" ? "إعادة المحاولة" : "Retry connection", for: .normal)
            retry.addAction(UIAction { [weak web, weak retry] _ in
                retry?.removeFromSuperview()
                web?.load(URLRequest(url: site))
            }, for: .touchUpInside)
            retry.translatesAutoresizingMaskIntoConstraints = false
            web.addSubview(retry)
            NSLayoutConstraint.activate([retry.centerXAnchor.constraint(equalTo: web.centerXAnchor), retry.centerYAnchor.constraint(equalTo: web.centerYAnchor)])
        }
    }
}

private struct OpenPassButton: View {
    let arabic: Bool
    var continueDemo: (() -> Void)? = nil
    @State private var openedDemo = false
    @State private var unavailable = false
    var body: some View {
        if openedDemo, let continueDemo {
            Button(arabic ? "متابعة بشخصية افتراضية" : "Continue with fictional demo profile", action: continueDemo)
            Button(arabic ? "إلغاء" : "Cancel") { openedDemo = false }
        } else {
        Button {
            UIApplication.shared.open(URL(string: "uaepass://")!) { opened in
                openedDemo = opened && continueDemo != nil
                unavailable = !opened
            }
        } label: {
            Label(continueDemo == nil ? (arabic ? "فتح تطبيق الهوية الرقمية" : "Open UAE PASS app") : (arabic ? "الدخول بالهوية الرقمية (تجريبي)" : "Sign in with UAE PASS (demo)"), systemImage: "arrow.up.forward.app")
        }
        .alert(arabic ? "تعذّر فتح تطبيق الهوية الرقمية" : "Couldn’t open UAE PASS", isPresented: $unavailable) {
            Button(arabic ? "موافق" : "OK") {}
        } message: {
            Text(arabic ? "تأكد من تثبيت التطبيق الرسمي ثم حاول مجدداً." : "Check that the official UAE PASS app is installed, then try again.")
        }
        }
    }
}

private struct SignInView: View {
    @Binding var language: String
    let onSuccess: (Session) throws -> Void
    @State private var signup = false
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var busy = false
    @State private var error = ""
    private func t(_ ar: String, _ en: String) -> String { language == "ar" ? ar : en }

    var body: some View {
        Form {
            Section {
                HStack { Spacer(); Image("LargeIcon").resizable().scaledToFit().frame(height: 130); Spacer() }
                Picker("Language", selection: $language) { Text(verbatim: "العربية").tag("ar"); Text(verbatim: "English").tag("en") }.pickerStyle(.segmented)
            }
            Section {
                Picker(t("الحساب","Account"), selection: $signup) {
                    Text(t("تسجيل الدخول","Sign in")).tag(false)
                    Text(t("إنشاء حساب","Create account")).tag(true)
                }.pickerStyle(.segmented)
                if signup { TextField(t("الاسم","Name"), text: $name).textContentType(.name) }
                TextField(t("البريد الإلكتروني","Email"), text: $email)
                    .textContentType(.username).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
                SecureField(t("كلمة المرور","Password"), text: $password)
                    .textContentType(signup ? .newPassword : .password)
                Button {
                    Task { await authenticate() }
                } label: {
                    if busy { ProgressView() }
                    else { Text(signup ? t("إنشاء حساب","Create account") : t("تسجيل الدخول","Sign in")) }
                }.disabled(email.isEmpty || password.isEmpty || (signup && (password.count < 8 || name.isEmpty)))
                if !error.isEmpty { Text(error).foregroundStyle(.red) }
            } footer: {
                if signup { Text(t("كلمة المرور ٨ أحرف على الأقل","Use at least 8 characters for your password.")) }
            }
            Section {
                OpenPassButton(arabic: language == "ar") {
                    Task { await authenticate(guest: true, demo: true) }
                }
                Button(t("المتابعة كضيف", "Continue as guest")) {
                    Task { await authenticate(guest: true) }
                }
            }
        }.disabled(busy)
    }

    private struct Reply: Decodable {
        let token: String?
        let user: Account?
        let error_ar: String?
        let error_en: String?
    }
    private func authenticate(guest: Bool = false, demo: Bool = false) async {
        guard !busy else { return }
        busy = true; error = ""
        defer { busy = false }
        do {
            let path = demo ? "demo-pass" : guest ? "guest" : (signup ? "signup" : "login")
            var request = URLRequest(url: site.appendingPathComponent("api/auth/" + path))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            var body = ["email":email.trimmingCharacters(in: .whitespacesAndNewlines),"password":password]
            if signup { body["name"] = name }
            request.httpBody = try JSONEncoder().encode(guest ? [:] : body)
            let (data, response) = try await URLSession.shared.data(for: request)
            let reply = try JSONDecoder().decode(Reply.self, from: data)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  let token = reply.token, !token.isEmpty, let user = reply.user else {
                error = (language == "ar" ? reply.error_ar : reply.error_en) ?? t("تعذّر الدخول","Sign-in failed")
                return
            }
            try onSuccess(Session(token: token, user: user, lang: language))
            password = ""
        } catch { self.error = t("تعذّر إكمال تسجيل الدخول. حاول مرة ثانية.","Could not complete sign-in. Please try again.") }
    }
}
