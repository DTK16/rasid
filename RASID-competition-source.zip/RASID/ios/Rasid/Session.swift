import Foundation

struct Account: Codable {
    let email: String
    let name: String
    let role: String
}

struct Session: Codable {
    let token: String
    let user: Account
    var protect = false
    var lang: String
    static let group = "group.ae.rasid.Rasid"

    private static func file() throws -> URL {
        guard let dir = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw CocoaError(.fileNoSuchFile)
        }
        return dir.appendingPathComponent("session.json")
    }
    static func load() throws -> Session? {
        let url = try file()
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        return try JSONDecoder().decode(Session.self, from: Data(contentsOf: url))
    }
    func save() throws {
        var url = try Self.file()
        try JSONEncoder().encode(self).write(to: url, options: [.atomic, .completeFileProtection])
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try url.setResourceValues(values)
    }
    static func clear() throws {
        let url = try file()
        if FileManager.default.fileExists(atPath: url.path) { try FileManager.default.removeItem(at: url) }
    }
}
