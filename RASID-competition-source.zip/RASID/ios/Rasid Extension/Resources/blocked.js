// Rasid block screen (inside the extension). Shows why the link was stopped, in the language chosen on
// the Rasid site. Text is set with textContent only.
(function () {
  var q = new URLSearchParams(location.search);
  var en = q.get("lang") === "en";
  var T = function (ar, e) { return en ? e : ar; };
  document.documentElement.lang = en ? "en" : "ar";
  document.documentElement.dir = en ? "ltr" : "rtl";
  var host = "";
  try { host = new URL(q.get("u") || "").hostname; } catch (e) {}
  var set = function (id, text) { document.getElementById(id).textContent = text.replaceAll("—", "·"); };
  set("title", T("تم منع الموقع", "Site blocked"));
  set("sub", T("منع راصد هذا الموقع لحمايتك", "Rasid blocked this site to protect you"));
  if (q.get("level") === "dangerous") set("title", T("رابط خطير", "Dangerous link"));
  if (q.get("level") === "suspicious") {
    set("title", T("رابط مشبوه", "Suspicious link"));
    set("sub", T("راجع السبب قبل المتابعة", "Review the warning before continuing"));
    const button = document.getElementById("continue");
    button.hidden = false;
    button.textContent = T("فتح على أي حال", "Open anyway");
    button.onclick = () => browser.runtime.sendMessage({type:"continue", url:q.get("u")});
  }
  if (q.get("level") === "dangerous") browser.runtime.sendMessage({type:"dangerDisplayed",url:q.get("u")}).then(ok => {
    set("sub",ok ? T("بلاغ تجريبي داخل راصّد فقط","Simulated police report saved in Rasid only") : T("تعذر حفظ البلاغ التجريبي","Demo report unavailable"));
  }).catch(()=>{});
  set("host", host);
  set("why", en
    ? (q.get("en") || "Could not verify this site, so it was blocked as a precaution") + (q.get("se") ? " · " + q.get("se") : "")
    : (q.get("ar") || "تعذّر التحقق من الموقع، فتم منعه احتياطاً") + (q.get("s") ? " · " + q.get("s") : ""));
  set("close", T("✕ إغلاق الصفحة", "✕ Close this page"));
  set("report", T("أبلغ الجهات المختصة", "Report it"));
  document.getElementById("close").addEventListener("click", function () {
    browser.tabs.getCurrent().then(function (t) { return browser.tabs.remove(t.id); }).catch(function () { location.replace("about:blank"); });
  });
  document.getElementById("report").addEventListener("click", function () {
    location.href = "https://rasid-link-checker.netlify.app/?report=1";
  });
})();
