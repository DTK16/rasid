// Rasid Safari extension · runs at the very start of every page.
// The native app supplies the session and protection preference.
// 2) On any other site, when protection is on: stops the page, checks it with Rasid,
//    reloads it only if Rasid says it is safe, otherwise shows a block screen.
(function () {
  "use strict";
  var RASID_ORIGIN = "https://rasid-link-checker.netlify.app";
  var EN = false; // follows the language chosen on the Rasid site
  var T = function (ar, en) { return EN ? en : ar; };

  if (location.origin === RASID_ORIGIN) return;
  if (window.top !== window) return;
  if (!/^https?:$/.test(location.protocol)) return;
  browser.runtime.sendMessage({ type: "status", url: location.href }).then(function (st) {
    if (!st || !st.active) return; // protection is off or not signed in: do nothing
    EN = st.lang === "en";
    protectCardForms();
    if (st.continued) return;
    if (st.known) { // already checked as safe in the last 30 minutes
      prepareInternalLinks();
      toast(T("✓ راصد: موقع آمن (تم رصده سابقاً)", "✓ Rasid: no warning signs found"));
      return;
    }
    window.stop();                  // nothing on this page loads until Rasid has checked it
    var ui = screen("#0f2a44");
    ui.add("div", "font-size:54px;margin-bottom:8px", "⌛");
    ui.add("div", "font-size:26px;font-weight:800", T("راصد يرصد الموقع…", "Rasid is checking this site…"));
    ui.add("div", "font-size:14px;opacity:.85;margin-top:4px", T("لن يُفتح الموقع قبل أن يتأكد راصد منه", "It will not open until Rasid has checked it"));
    ui.add("div", "font-size:13px;opacity:.75;margin-top:12px;word-break:break-all;direction:ltr", location.hostname);

    browser.runtime.sendMessage({ type: "check", url: location.href }).then(function (r) {
      if (r && (r.allow || r.inactive)) {
        location.reload();
      } else {
        if (r?.level === "suspicious") {
          browser.runtime.sendMessage({type:"showWarning", url:location.href});
        }
        blocked(r || {});
      }
    }, function () { blocked({}); });
  }, function () {});

  // Inspect field metadata and the submission destination, never payment values.
  function protectCardForms() {
    const card = 'input[autocomplete~="cc-number" i],input[autocomplete~="cc-csc" i]';
    function stopInsecurePayment(event) {
      const target = event.target;
      const submitting = event.type === "submit";
      const form = submitting ? target : target.form;
      if (submitting) {
        if (!(form instanceof HTMLFormElement) ||
            !Array.from(form.elements).some(element => element.matches(card))) return;
      } else if (!target.matches?.(card)) return;
      const submitter = submitting ? event.submitter : null;
      const action = submitter?.hasAttribute("formaction") ? submitter.getAttribute("formaction") : form?.getAttribute("action");
      const destination = new URL(action || location.href, document.baseURI);
      if (location.protocol === "https:" && destination.protocol === "https:") return;
      event.preventDefault();
      event.stopImmediatePropagation();
      window.stop();
      blocked({
        reason_en: "This checkout uses an insecure connection for card details.",
        reason_ar: "تستخدم صفحة الدفع اتصالاً غير آمن لبيانات البطاقة."
      });
    }
    for (const type of ["focusin", "beforeinput", "submit"]) {
      window.addEventListener(type, stopInsecurePayment, true);
    }
  }

  // Keep the current page visible while checking ordinary same-site navigation.
  function prepareInternalLinks() {
    let navigation = 0;
    let notice;
    window.addEventListener("click", async function (event) {
      if (!event.isTrusted || event.defaultPrevented || event.button !== 0 ||
          event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor = event.target.closest?.("a[href]");
      if (!anchor || anchor.hasAttribute("download") || anchor.hasAttribute("onclick") ||
          (anchor.target && anchor.target !== "_self") || document.querySelector("base[target]")) return;
      const url = new URL(anchor.href, location.href);
      if (url.origin !== location.origin || url.pathname + url.search === location.pathname + location.search) return;
      event.preventDefault();
      const request = ++navigation;
      const from = location.href;
      notice?.remove();
      const timer = setTimeout(() => {
        if (request !== navigation || location.href !== from) return;
        notice = document.createElement("div");
        notice.setAttribute("role", "status");
        notice.style.cssText = "position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#163448;color:white;border-radius:18px;padding:8px 14px;font:500 14px system-ui;pointer-events:none";
        notice.textContent = T("راصد يفحص الرابط…", "Checking link…");
        document.body.append(notice);
      }, 350);
      try {
        // The destination page reuses only a successful exact-URL verdict.
        // Other results use the existing destination warning and override flow.
        await browser.runtime.sendMessage({type:"prepare", url:url.href});
      } catch {
        // The destination still runs its normal protection check.
      } finally {
        clearTimeout(timer);
        if (request === navigation) {
          notice?.remove();
          if (location.href === from) location.assign(url.href);
        }
      }
    });
  }

  // Small green note at the top of a page Rasid let through.
  function toast(text) {
    var show = function () {
      if (!document.body) return;
      var t = document.createElement("div");
      t.textContent = text;
      t.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#14532d;color:#fff;padding:10px 16px;border-radius:999px;font:600 14px -apple-system,system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);max-width:90vw;text-align:center;direction:rtl";
      document.body.appendChild(t);
      setTimeout(function () { t.style.transition = "opacity .6s"; t.style.opacity = "0"; }, 2800);
      setTimeout(function () { t.remove(); }, 3500);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
  }

  function blocked(r) {
    var ui = screen("#7a1610");
    ui.add("div", "font-size:54px;margin-bottom:8px", "⛔");
    ui.add("div", "font-size:28px;font-weight:800", T("تم منع الموقع", "Site blocked"));
    ui.add("div", "font-size:15px;opacity:.9;margin-top:2px", T("منع راصد هذا الموقع لحمايتك", "Rasid blocked this site to protect you"));
    ui.add("div", "font-size:13px;opacity:.8;margin-top:12px;word-break:break-all;direction:ltr", location.hostname);
    ui.add("div", "margin-top:16px;padding:12px 14px;border-radius:12px;background:rgba(255,255,255,.12);font-size:15px;max-width:460px",
      EN ? (r.reason_en || "Could not verify this site, so it was blocked as a precaution") + (r.summary_en ? " · " + r.summary_en : "")
         : (r.reason_ar || "تعذّر التحقق من الموقع، فتم منعه احتياطاً") + (r.summary_ar ? " · " + r.summary_ar : ""));
    if (r.level === "dangerous") browser.runtime.sendMessage({type:"dangerDisplayed",url:location.href}).then(ok => {
      ui.add("div","margin-top:8px",ok ? T("بلاغ تجريبي داخل راصّد فقط","Simulated police report saved in Rasid only") : T("تعذر حفظ البلاغ التجريبي","Demo report unavailable"));
    }).catch(()=>{});
    var back = ui.add("button", "margin-top:22px;min-height:50px;padding:10px 26px;border:none;border-radius:12px;background:#fff;color:#0f2a44;font-size:17px;font-weight:700", T("↩ رجوع", "↩ Go back"));
    back.addEventListener("click", function () { if (history.length > 1) history.back(); else location.replace("about:blank"); });
    var rep = ui.add("button", "margin-top:10px;min-height:46px;padding:10px 22px;border:1px solid rgba(255,255,255,.6);border-radius:12px;background:transparent;color:#fff;font-size:15px;font-weight:600", T("أبلغ الجهات المختصة", "Report it"));
    rep.addEventListener("click", function () { location.href = RASID_ORIGIN + "/?report=1"; });
  }

  function screen(bg) {
    var root = document.documentElement;
    while (root.firstChild) root.removeChild(root.firstChild);
    var body = document.createElement("body");
    root.appendChild(body);
    root.setAttribute("dir", EN ? "ltr" : "rtl");
    var box = document.createElement("div");
    box.style.cssText = "position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;color:#fff;font-family:-apple-system,system-ui,sans-serif;background:" + bg;
    body.style.cssText = "margin:0";
    body.appendChild(box);
    return {
      add: function (tag, css, text) {
        var n = document.createElement(tag);
        n.style.cssText = css;
        n.textContent = text.replaceAll("—", "·");
        box.appendChild(n);
        return n;
      },
    };
  }
})();
