// Rasid Safari extension — background.
// Keeps the user's Rasid sign-in and protection switch (copied from the Rasid site), asks the Rasid
// server whether a page may open, and remembers sites already checked as safe (for 30 minutes) so
// moving around the same site, or a redirect like bbc.com → www.bbc.com, does not trigger a new check.
// Anything uncertain is blocked (fail-safe).

const RASID = "https://rasid-link-checker.netlify.app";
const SAFE_TTL_MS = 30 * 60 * 1000;
// Cache exact URLs in extension memory only for the current signed-in session.
const safe = new Map();
const pending = new Map();
const warnings = new Map();
const exceptions = new Map();
browser.tabs.onRemoved.addListener(id => { warnings.delete(id); exceptions.delete(id); });
let activeToken = null;

async function getState() {
  const state = await browser.runtime.sendNativeMessage("ae.rasid.Rasid", {type: "state"});
  const token = state.protect ? state.token : null;
  if (activeToken !== token) {
    warnings.clear();
    exceptions.clear();
    pending.clear();
    safe.clear();
    activeToken = token;
  }
  return state;
}

function checkOnce(url, token) {
  if (!pending.has(url)) {
    const job = checkUrl(url, token).then(result => {
      if (result.allow && activeToken === token) {
        if (safe.size >= 512) safe.delete(safe.keys().next().value);
        safe.set(url, Date.now() + SAFE_TTL_MS);
      }
      return result;
    }).finally(() => { if (pending.get(url) === job) pending.delete(url); });
    pending.set(url, job);
  }
  return pending.get(url);
}

async function checkUrl(url, token) {
  try {
    const res = await fetch(RASID + "/api/check", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ url, mode: "gate" }),
    });
    const j = await res.json().catch(() => ({}));
    if (res.status === 401) return { allow: false, login: true, reason_ar: "سجّل الدخول إلى راصد من جديد", reason_en: "Sign in to Rasid again" };
    const g = j.gate || {};
    return {
      allow: !!g.allow,
      level: j.verdict ? j.verdict.level : null,
      reason_ar: g.reason_ar || j.error_ar || "تعذّر التحقق من الموقع، فتم منعه احتياطاً",
      reason_en: g.reason_en || j.error_en || "Could not verify this site, so it was blocked",
      summary_ar: j.ai && j.ai.summary_ar ? j.ai.summary_ar : null,
      summary_en: j.ai && j.ai.summary_en ? j.ai.summary_en : null,
    };
  } catch (e) {
    return { allow: false, reason_ar: "لا يوجد اتصال بخادم راصد، فتم منع الموقع احتياطاً", reason_en: "Could not reach Rasid, so the site was blocked as a precaution" };
  }
}

browser.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !msg.type) return;
  const id = sender.tab?.id;
  if (msg.type === "continue" && sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html")) {
    return getState().then(s => {
      if (!s.protect || !s.token || warnings.get(id) !== msg.url) return false;
      warnings.delete(id);
      exceptions.set(id, {url: msg.url, until: Date.now() + 15000});
      return browser.tabs.update(id, {url: msg.url}).then(() => true);
    });
  }
  if (msg.type === "showWarning" && sender.url === msg.url && sender.frameId === 0) {
    recent.delete(id + " " + msg.url);
    return watch(id, msg.url);
  }
  if (msg.type === "status") {
    return getState().then((s) => {
      const active = !!(s.token && s.protect);
      const known = active && safe.get(msg.url) > Date.now();
      return { active, known, continued: exceptions.get(id)?.url === msg.url && exceptions.get(id).until > Date.now(), lang: s.lang };
    });
  }
  if (msg.type === "dangerDisplayed") {
    const extensionPage = sender.url?.split("?")[0] === browser.runtime.getURL("blocked.html");
    if (sender.frameId !== 0 || (!extensionPage && sender.url !== msg.url)) return;
    return getState().then(async s => {
      if (!s.protect || !s.token) return false;
      const res = await fetch(RASID + "/api/demo/police-report", {
        method:"POST", headers:{"Content-Type":"application/json", Authorization:"Bearer "+s.token},
        body:JSON.stringify({url:msg.url})
      });
      return res.ok;
    });
  }
  if (msg.type === "prepare") {
    const destination = new URL(msg.url);
    if (sender.frameId !== 0 || !sender.url || destination.origin !== new URL(sender.url).origin ||
        !/^https?:$/.test(destination.protocol)) return;
    return getState().then(async s => {
      if (s.protect && s.token && !(safe.get(destination.href) > Date.now())) {
        await checkOnce(destination.href, s.token);
      }
      return true;
    });
  }
  if (msg.type === "check") {
    return getState().then(async s => {
      if (!s.protect || !s.token) return {inactive:true};
      const result = await checkOnce(String(msg.url || ""), s.token);
      const current = await getState();
      return current.protect && current.token === s.token ? result : {inactive:true};
    });
  }
});

// ---- Tab watcher: catches every link the moment Safari starts opening it — even a site that does not
// exist (where no page loads, so the page script never runs). If Rasid says no, the tab is sent to the
// Rasid block screen inside the extension.
const recent = new Map();
async function watch(tabId, url) {
  if (!url || !/^https?:/i.test(url) || new URL(url).origin === RASID) return;
  const exception = exceptions.get(tabId);
  if (exception?.url === url && exception.until > Date.now()) return;
  exceptions.delete(tabId);
  const key = tabId + " " + url;
  if (recent.has(key) && Date.now() - recent.get(key) < 5000) return;
  recent.set(key, Date.now());
  if (recent.size > 200) recent.clear();
  const s = await getState();
  if (!s.token || !s.protect) return;
  if (safe.get(url) > Date.now()) return;
  const r = await checkOnce(url, s.token);
  if (r.allow) return;
  const current = await getState();
  if (!current.protect || current.token !== s.token) return;
  try {
    const tab = await browser.tabs.get(tabId);
    if (tab.url !== url) return; // the user already went somewhere else
  } catch (e) { return; }
  if (r.level === "suspicious") warnings.set(tabId, url);
  else warnings.delete(tabId);
  const q = new URLSearchParams({ level: r.level || "", u: url, ar: r.reason_ar || "", en: r.reason_en || "", s: r.summary_ar || "", se: r.summary_en || "", lang: s.lang });
  browser.tabs.update(tabId, { url: browser.runtime.getURL("blocked.html") + "?" + q.toString() }).catch(() => {});
}
if (browser.webNavigation && browser.webNavigation.onErrorOccurred) {
  browser.webNavigation.onErrorOccurred.addListener((d) => { if (d.frameId === 0 && !/abort|cancel/i.test(d.error || "")) watch(d.tabId, d.url); });
}
